import UIKit
import SpriteKit
import SceneKit
import AVFoundation

/// This is a global Variable that will be used to get Scene3D elements
var scene3DObject = Scene3D()

/*! This is the first class that will be used.
  - It is the introduction to the story board and it will display a Can and it will be called CAN PARADIGM
  - It uses instance of Scene3D that has a predefined method that returns the first scene
  - It uses Autolayout - WDIL
 */
public class IntroductionController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate{

    /// 3D Scene is reuqired
    lazy var sceneView = SCNView()
    
    /// Background
    let backgroundColor = Paradigm.introductionBackgroundColor
    
    /// Can Material that will be on top of the Cylinder
    var canMaterial:SCNMaterial?
    
    /// Scene3D object to instantiate first scene
    //lazy var firstScene = Scene3D()
   
    ///Scene Label Title
    lazy var labelTitle = "Paradigm"
    
    /// Interactable
    var animationSpeed:Double = 12
    
    /// Animate Boolean
    var isAnimating = true
    
    /// Image Picker
    var imagePicker = UIImagePickerController()

    
    //MARK: - VIEW CONTROLLER METHODS
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.setupIntroductionView()
    }
    
    //MARK: - CUSTOM METHODS
    /*! This method places all the views using Layout Anchors
     1. It places a contentView that will hold a Label and a SceneView
     2. Label is placed at a bottom of contecnview with a fixed height of 50
     3. SceneView will be placed above label*/
    func setupIntroductionView() {
        
        //Change Background color
        self.view.backgroundColor = backgroundColor
    
        //Add content view
        let contentView = UIView()
        contentView.backgroundColor = backgroundColor
        self.view.addSubview(contentView)
        contentView.translatesAutoresizingMaskIntoConstraints = false
        //Will have to work on a class - WDIL
        contentView.heightAnchor.constraint(equalToConstant: 400).isActive = true
        contentView.widthAnchor.constraint(equalToConstant: 300).isActive = true
        contentView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        contentView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        
        //Add options view
        var optionsView = UIView()
        contentView.addSubview(optionsView)
        optionsView.backgroundColor = backgroundColor
        optionsView.translatesAutoresizingMaskIntoConstraints = false
        optionsView.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        optionsView.widthAnchor.constraint(equalToConstant: 120).isActive = true
        optionsView.heightAnchor.constraint(equalToConstant: 40).isActive = true
        optionsView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive = true
        optionsView.layer.cornerRadius = 20
        Paradigm.setShadow(_view: &optionsView, _shadowColor: UIColor.lightGray, _opacity: 0.4, _cornerRadius: 20)
        
        //This is the bar that will seperate camera and gallery options
        let seperatorBar = UIView()
        optionsView.addSubview(seperatorBar)
        seperatorBar.backgroundColor = UIColor.lightGray.withAlphaComponent(0.5)
        seperatorBar.translatesAutoresizingMaskIntoConstraints = false
        seperatorBar.widthAnchor.constraint(equalToConstant: 1).isActive = true
        seperatorBar.heightAnchor.constraint(equalToConstant: 20).isActive = true
        seperatorBar.centerXAnchor.constraint(equalTo: optionsView.centerXAnchor).isActive = true
        seperatorBar.centerYAnchor.constraint(equalTo: optionsView.centerYAnchor).isActive = true
        
        //Add a camera icon
        var cameraIcon = UIImageView(image: UIImage(named: "cameraIcon@2x.png"))
        optionsView.addSubview(cameraIcon)
        cameraIcon.contentMode = .center
        cameraIcon.isUserInteractionEnabled = true
        cameraIcon.translatesAutoresizingMaskIntoConstraints = false
        cameraIcon.topAnchor.constraint(equalTo: optionsView.topAnchor).isActive = true
        cameraIcon.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor).isActive = true
        cameraIcon.leadingAnchor.constraint(equalTo: optionsView.leadingAnchor).isActive = true
        cameraIcon.trailingAnchor.constraint(equalTo: seperatorBar.leadingAnchor).isActive = true
        Paradigm.attachTapGesture(&cameraIcon, target: self, action: #selector(getCamera))
        
        
        //Add a gallery icon
        var galleryIcon = UIImageView(image: UIImage(named: "galleryIcon@2x.png"))
        galleryIcon.contentMode = .center
        optionsView.addSubview(galleryIcon)
        galleryIcon.isUserInteractionEnabled = true
        galleryIcon.translatesAutoresizingMaskIntoConstraints = false
        galleryIcon.topAnchor.constraint(equalTo: optionsView.topAnchor).isActive = true
        galleryIcon.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor).isActive = true
        galleryIcon.leadingAnchor.constraint(equalTo: seperatorBar.trailingAnchor).isActive = true
        galleryIcon.trailingAnchor.constraint(equalTo: optionsView.trailingAnchor).isActive = true
        Paradigm.attachTapGesture(&galleryIcon, target: self, action: #selector(getGallery))
        
        //Label - CAN PARADIGM
        let label = Paradigm.getTextLabel(CGRect(x: 0, y: 0, width: 10, height: 10), defaultText: labelTitle, minimumScaleFactor: 10, fontSizex: 18, fontName: Paradigm.signatureFontName)
        contentView.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 0).isActive = true
        label.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: 0).isActive = true
        label.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        label.heightAnchor.constraint(equalToConstant: 40).isActive = true
        label.backgroundColor = backgroundColor
        
        //SceneView
        sceneView = scene3DObject.getSceneView(CGRect(x: 0, y: 0, width: 100, height: 100), allowsCameraControl: false, showStatistics: false, playing: true, scene: setupFirstScene(), delegate: nil)
        contentView.addSubview(sceneView)
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        sceneView.topAnchor.constraint(equalTo: optionsView.bottomAnchor, constant: 10).isActive = true
        sceneView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 0).isActive = true
        sceneView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: 0).isActive = true
        sceneView.bottomAnchor.constraint(equalTo: label.topAnchor).isActive = true

    }
    
    /*! This function is there to setup first scene.
     1. It has a Cylinder with a Glitch Shader on it.
     2. Cylinder also rotates*/
    public func setupFirstScene() -> SCNScene {
        
        //Basic scene setup
        let scene = scene3DObject.getScene(nil)
        //sceneView = scene3DObject.getSceneView(frame, allowsCameraControl: false, showStatistics: false, playing: true, scene: scene, delegate: nil)
        
        //Get camera node
        let camera = scene3DObject.getCamera()
        var cameraNode = scene3DObject.getCameraWithNode(camera, position: SCNVector3(x: -2, y: 2, z: 2))
        
        //Get light node
        let light = scene3DObject.getLight()
        var lightNode = scene3DObject.getLightNode(light, position: SCNVector3(x: 1.5, y: 1.5, z: 1.5))
        
        
        /*EXPS STARTS*/
        //Create nodes
        canMaterial = scene3DObject.getMaterial(.red, shaders: nil, fresnelEffect: true)
        scene3DObject.attachShaderPrograms(&canMaterial, fragment_function: "glitchFragment", vertex_function: "glitchVertex", file: "GlitchShader")
        scene3DObject.attachTextureToMaterial(&canMaterial, imageName: "apple2.png", key: "diffuseTexture")
        let canParadigm = scene3DObject.getCylinderNode(materials: canMaterial)
        
        //Rotate it forever
        if(isAnimating) {
            let action = SCNAction.rotateBy(x: 0, y: CGFloat(GLKMathDegreesToRadians(360)), z: 0, duration: animationSpeed)
            let rotateAlltime = SCNAction.repeatForever(action)
            canParadigm.runAction(rotateAlltime)
        }
        
        //3D constraints
        let lookAtConstraints = scene3DObject.getLookConstraint(canParadigm)
        scene3DObject.attachLookConstraint(&cameraNode, constraints: lookAtConstraints)
        scene3DObject.attachLookConstraint(&lightNode, constraints: lookAtConstraints)
        
    
        //Add them to the scene
        scene.rootNode.addChildNode(lightNode)
        scene.rootNode.addChildNode(cameraNode)
        scene.rootNode.addChildNode(canParadigm)
        
        return scene
    }
    
    //MARK: - Camera Button
    /*! Get pictures from camera and place it on top of the texture*/
    @objc func getCamera() {
        print("I am camera view")
        imagePicker.sourceType = .camera
        imagePicker.allowsEditing = true
        imagePicker.delegate = self
        present(imagePicker, animated: true)
        
    }
    
    @objc func getGallery() {
        print("I am camera view")
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = true
        imagePicker.delegate = self
        present(imagePicker, animated: true)
    }
    
    
    
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        guard let image = info[.editedImage] as? UIImage else {
            print("No image found")
            return
        }
        //Image cutting will be required in future
        scene3DObject.attachImageToMaterial(canMaterial, image: image, key: "diffuseTexture")
        print(image.size)
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
}

