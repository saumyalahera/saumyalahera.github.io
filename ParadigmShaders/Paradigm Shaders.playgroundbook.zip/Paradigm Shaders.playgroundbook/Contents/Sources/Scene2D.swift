import Foundation
import PlaygroundSupport
import UIKit
import SpriteKit

/*
 -  This class is the main classs that will load all the 2D scenes
 -  It uses a lot of modules of SpriteKit
 -  It will load 2D shaders because paintings will need top down view and it is 2D
 */
public class Scene2D {
    
    /// This is the main view where everything will be rendered
    lazy var sceneView:SKView? = nil
    
    /// This is the scene object that will be the heart of
    var scene:SKScene?
    
    //MARK: - BASIC METHODS
    /// Init function
    public init() {
       
    }
    
    /*Setup scene will make*/
    public func getScene(_ frame: CGRect, texture: String, shader: String) -> SKScene{
        
        sceneView = SKView(frame: frame)
        scene = SKScene(size: frame.size)
        
        //It is possible that texture or shader is not loaded so do not add that node
        if let node = attachNode(texture, shader: shader) {
            scene?.addChild(node)
        }
        scene?.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        scene?.backgroundColor = SKColor.clear
        scene?.scaleMode = .aspectFit
        return scene!
    }
    
    /*
     This function is the one that loads Shader and Texture.
     Reason for using 2D shader is because it has to be shown from the top view.
     */
    func attachNode(_ texture: String, shader: String) -> SKSpriteNode? {
        
        let node = SKSpriteNode(imageNamed: texture)
        node.position = CGPoint(x: 0.0, y: 12.0);
        node.shader = SKShader(fileNamed: shader)
        return node
    }
    
}

