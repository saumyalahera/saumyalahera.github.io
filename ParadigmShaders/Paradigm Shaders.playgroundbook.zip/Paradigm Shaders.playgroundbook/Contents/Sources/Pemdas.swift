import UIKit
import SceneKit

/*! This is a class holds information:
 1. Object geometry
 2. Object color
 3. Object shader
 - Using this class we will decide random elements and PEMDAS questions*/
class ElementType {
    var types:[String:Int]!
    public init() {
        types = [String:Int]()
    }
}


/*! This game is about calculating answers and until you get a wrong answer
 - Your winnning streak is your score
 - Patterns are going to be random and that will be fun to play
 - There are also difficulty levels (5x5 or 7x7)
 - Fun part is that each element is going to have a different shader
 - Now, level one will be only one geometry
 - Level2 will have multiple geometries
 */
public class Pemdas {
    
    
    /// Add a camera
    var cameraNode:SCNNode!
    
    /// Light Node
    var lightNode:SCNNode!
    
    /// scene object will take care of the current scene.
    var scene:SCNScene?
    
    /// Metal device is needed for Metal Libraries that will be used for shaders
    lazy var device = MTLCreateSystemDefaultDevice()
    
    ///LookAt constraints
    var lookAtConstraints:SCNLookAtConstraint?
    
    //Scene3D Object
    lazy var scene3DObject = Scene3D()
    
    //Some constants
    let shapes = ["Sphere","Cube","Pyramid"]
    let colors = ["Red","Blue","Black","Green"]
    let shaders = ["glitch","toon","rainbow"]
    let patters = ["p1","p2","p3","p4"]
    
    //Types
    var shapeElements = ElementType()
    var colorElements = ElementType()
    var shaderElements = ElementType()
    
    ///Operator Limit - This defines the difficulty level
    let operatorLimit = 3
    
    
    
    //PERRFECT TILL NOW
    func generatePatternOne() -> (scene:SCNScene, expression: String, answer:Float){
        
        //Empty all the objects
        shapeElements.types.removeAll()
        shaderElements.types.removeAll()
        colorElements.types.removeAll()
        
        //Get camera node
        let camera = scene3DObject.getCamera()
        cameraNode = scene3DObject.getCameraWithNode(camera, position: SCNVector3(x: -0.8, y: 1, z: 9))
        
        //Get light node
        let light = scene3DObject.getLight(.directional)
        lightNode = scene3DObject.getLightNode(light, position: SCNVector3(x: 1.5, y: 1.5, z: 1.5))
        
        //Main scene that will hold all the objects
        let scene = SCNScene()
        
        //These constants are used to calculate all the elements to be placed in an environment
        let c = 4
        let predicate:Float = Float(c)/2
        let spacing:Float = 0.8
        let z:Float = 0
        
        //This will add some
        var x = -(predicate+(predicate*spacing))
        var y = (predicate+(predicate*spacing))
        
        
        //Compute Random elements and add them to the Scene
        //Loop One
        for _ in 0..<c {
            //Reset x coordinates
            x = -(predicate+(predicate*spacing))
            //Loop Two
            for _ in 0..<c {
                
                var material:SCNMaterial?
                let shaderOrColor = Int.random(in: 0...1)
                
                if(shaderOrColor == 0){
                    //Shader
                    let shader = Int.random(in: 0..<self.shaders.count)
                    let shaderCount = shaderElements.types[shaders[shader]]
                    if(shaderCount == nil){
                        shaderElements.types["\(shaders[shader])"] = 1
                    }else {
                        shaderElements.types["\(shaders[shader])"] = shaderCount! + 1
                    }
                    //Create a mterial
                    material = self.getMaterialFromShaderString(shaders[shader])
                }else {
                    //Color
                    let color = Int.random(in: 0..<self.colors.count)
                    let colorCount = colorElements.types[colors[color]]
                    if(colorCount == nil){
                        colorElements.types["\(colors[color])"] = 1
                    }else {
                        colorElements.types["\(colors[color])"] = colorCount! + 1
                    }
                    material = getMaterialFromColorString(colors[color])
                }
                //CREATE AN A MATERIAL AND PLACE IT ON NODE
                
                //RANDOM SHAPE
                let shape = Int.random(in: 0..<self.shapes.count)
                let shapeCount = shapeElements.types[shapes[shape]]
                if(shapeCount == nil){
                    shapeElements.types["\(shapes[shape])"] = 1
                }else {
                    shapeElements.types["\(shapes[shape])"] = shapeCount! + 1
                }
                let node = getNodeFromString(shapes[shape], position: SCNVector3(x,y,z), materials: material)
                //Animation starts
                node.removeAllActions()
                let action = SCNAction.rotateBy(x: 0, y: CGFloat(GLKMathDegreesToRadians(360)), z: 0, duration: 22)
                let rotateAlltime = SCNAction.repeatForever(action)
                node.runAction(rotateAlltime)
                //Animation ends
                scene.rootNode.addChildNode(node)
                x+=(1+spacing)
            }
            y-=(1+spacing)
        }
        scene.rootNode.addChildNode(lightNode)
        scene.rootNode.addChildNode(cameraNode)
        print("Shapes: \(shapeElements.types!)")
        print("Shaders: \(shaderElements.types!)")
        print("Colors: \(colorElements.types!)")
        let result = self.generateQuestionAnswer(shapeElements, colors: colorElements, shaders: shaderElements, operatorLimit: 6)
        return (scene,result.question, result.answer)
        
    }
    
    func generatePatternTwo() {
        
    }
    
    func generatePatternThree() {
        
    }
    
    func geretarePatternFour() {
        
    }
    
    //create a random pattern, create a question and create an answer for that also.
    @discardableResult func generateQuestionAnswer(_ shapes: ElementType, colors: ElementType, shaders:ElementType, operatorLimit: Int) -> (question: String, answer: Float) {
        
        //let shapesx = ["sphere","cube","pyramid"]
        //let colorsx = ["red","blue","black","green"]
        
        
        //Always keep in mind that operators should be more than 2 always
        let operators = Int.random(in: 2...operatorLimit)
        print("Operators: \(operators)")
        //Expressions
        var expression = ""
        var question = ""
        
        for i in 0..<operators+1 {
            
            if(i%2 == 0) {
                //Operand
                let count = Int.random(in: 0..<3)
                //This is jut in case values are not nil or zero. It can be a big issue
                let randomNumber = Int.random(in: 0..<100)
                if(count == 0){
                    //Shapes
                    print("\(i): shapes")
                    let shape:String? = Array(shapes.types.keys)[Int.random(in: 0..<shapes.types.keys.count)]
                    let count = shapes.types[shape ?? "circle"]
                    expression+="\(count ?? randomNumber)"
                    question+="\(shape ?? String(randomNumber)) "
                }else {
                    //Colors
                    print("\(i): colors")
                    let color:String? = Array(colors.types.keys)[Int.random(in: 0..<colors.types.keys.count)]
                    let count = colors.types[color ?? "circle"]
                    expression+="\(count ?? randomNumber)"
                    question+="\(color ?? String(randomNumber)) "
                }
                
            }else {
                //Operator
                if(i != operators){
                    print("\(i): operators")
                    let operators = ["+","-","/","*"]
                    let random = operators[Int.random(in: 0..<operators.count)]
                    expression+="\(random)"
                    question+="\(random) "
                }
            }
        }
        
        var resultx:Float = 0.0
        let expr = NSExpression(format: expression)
        if let result = expr.expressionValue(with: nil, context: nil) as? Float {
            print("Result: \(result)")
            resultx = result// -0.25
        } else {
            print("failed")
            //Create a random expression
        }
        print("\(question)\n\(expression)")
        return ("\(question)\n\(question)",resultx)
    }
    
    func getNodeFromString(_ name:String, position:SCNVector3, materials:SCNMaterial?) -> SCNNode{
        
        var node = scene3DObject.getBoxWithNode(1, height: 1, length: 1, cornerRadius: 0, position: position, materials: materials)
        switch name {
        case "Sphere":
            node = scene3DObject.getSphereWithNode(0.5, position: position, materials: materials)
        case "Cylinder":
            node = scene3DObject.getCylinderNode(1, height: 1, position: position, materials: materials)
        case "Torus":
            node = scene3DObject.getTorusNode(1, pipeRadius: 1, position: position, materials: materials)
        case "Pyramid":
            node = scene3DObject.getPyramidNode(1, height: 1, length: 1, position: position, materials: materials)
        default:
            print("default")
        }
        return node
    }
    
    func getMaterialFromColorString(_ color: String) -> SCNMaterial? {
        var currentColor = UIColor.red
        switch color {
        case "Blue":
            currentColor = UIColor.blue
        case "Black":
            currentColor = UIColor.black
        case "Green":
            currentColor = UIColor.green
        default:
            print("Default")
        }
        let material = scene3DObject.getMaterial(currentColor, shaders: nil, fresnelEffect: false)
        return material
    }
    
    func getMaterialFromShaderString(_ name:String) -> SCNMaterial?{
        var material:SCNMaterial?
        if(name == "toon") {
            var toonShaderModifier = NSMutableDictionary()
            scene3DObject.attachEntryPointFromFile(&toonShaderModifier, entrypoint: .lightingModel, name: "toon", type: "shader")
            material = scene3DObject.getMaterial(shaders: toonShaderModifier)
        }else if(name == "glitch") {
            var glitchMaterial:SCNMaterial? = scene3DObject.getMaterial(.red, shaders: nil, fresnelEffect: false)
            scene3DObject.attachShaderPrograms(&glitchMaterial, fragment_function: "smokeFragment", vertex_function: "smokeVertex", file: "SmokeShader")
            material = glitchMaterial
        }else if(name == "rainbow"){
            var rainbowMaterial:SCNMaterial? = scene3DObject.getMaterial(.red, shaders: nil, fresnelEffect: false)
            scene3DObject.attachShaderPrograms(&rainbowMaterial, fragment_function: "rainbowPaintingFragment", vertex_function: "rainbowPaintingVertex", file: "RainbowPaintingVertex")
            material = rainbowMaterial
        }else {
            var toonShaderModifier = NSMutableDictionary()
            scene3DObject.attachEntryPointFromFile(&toonShaderModifier, entrypoint: .lightingModel, name: "toon", type: "shader")
            material = scene3DObject.getMaterial(shaders: toonShaderModifier)
        }
        return material
    }
    
}
