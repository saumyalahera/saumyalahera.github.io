import UIKit
import SceneKit



/*! This is the game class
 1. This game is about PEMDAS
 1. P - Parentheses first
 2. E - Exponents (ie Powers and Square Roots, etc.)
 3. MD - Multiplication and Division (left-to-right)
 4. AS - Addition and Subtraction (left-to-right)*/
public class PemdasController: UIViewController {
    
    
    //MARK: - PROPERTIES
    var backgroundColor = UIColor.white
    
    //Score label
    var scoreLabel = UILabel()
    var countdownLabel = UILabel()
    
    /// This is the sceneView
    var sceneView = SCNView()
    
    ///Constraint that will be used to display timer
    var contentHeightConstraint:NSLayoutConstraint!
    
    /// Labels
    var timer = UILabel()
    var question = UILabel()
    
    /// Options
    var buttonLabelOne = UILabel()
    var buttonLabelTwo = UILabel()
    var buttonLabelThree = UILabel()
    
    /// Menu
    var menu = UIVisualEffectView()

    //Timer
    var countDownTimer:Timer!
    var countDown = 90
    
    /// This holds the actual answera and score details
    var answer:Float = 0
    var score = 0
    
    //Fail screen constant
    var menuInDisplay = true
    var options:[Float] = [12.4,45.6,66.7]
    
    //Game PEMDAS Object
    lazy var game = Pemdas()
    
    //MARK: - VIEW CONTROLLER METHODS
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.setupViews()
        self.view.backgroundColor = backgroundColor
    }
    
    //MARK: - TIMER METHODS
    /*! This is the start method. By default the countdown in 60.
     - Also it keeps track of the timer bar.
     - Timer label is substituted by the timer bar*/
    func startTimer() {
        countDown = 90
        countdownLabel.text = "\(countDown)"
        countDownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(calculateTime), userInfo: nil, repeats: true)
    }
    
    
    /*! This is the main function that calculates time.
     - It checks if the countdown is greater than zero.
     - If it is not and the answer is not selected, it will display main menu that indicates one lost the game*/
    @objc func calculateTime() {
        print("Countdown \(countDown)")
        if(countDown > 0){
            countDown-=1
            //infoBarTwoWidthConstraint.constant += (contentView.frame.width)/CGFloat(60)
            countdownLabel.text = "\(countDown)"
        }else {
            menuShow()
        }
    }
    
    
    //MARK: - LOAD SCENE
    func loadNewScene() {
        
        //Invalidate the counter
        if countDownTimer != nil { countDownTimer.invalidate() }
        
        //Generate scene
        let sceneInformation = game.generatePatternOne()
        sceneView.scene = sceneInformation.scene
        question.text = sceneInformation.expression
        
        //Generate other random options
        answer = sceneInformation.answer
        var option1:Float = 1//info.answer
        var option2:Float = 2//info.answer
        
        //This is tricky. You dont want user to understand the pattern of generating random numbers
        //So create a random number for patterns
        //There are three patterns
        // -- ++ and +-
        //This is not a good practice, however there is a limited time so it will work for now
        let optionGenerator = Int.random(in: 0...2)
        if(optionGenerator == 0) {
            //--
            option1 = answer-1
            option2 = answer-2
        }else if(option2 == 1) {
            //+-
            option1 = answer+1
            option2 = answer-1
        }else {
            //++
            option1 = answer+1
            option2 = answer+2
        }
        //Remove all the previous options and add new ones
        self.options.removeAll()
        self.options = [answer,option1,option2]
        self.options.shuffle()
        
        //Assign them to the Button Labels
        buttonLabelOne.text = "\(options[0])"
        buttonLabelTwo.text = "\(options[1])"
        buttonLabelThree.text = "\(options[2])"
        
        //Start the timer for a new scene
        startTimer()
    }
    
    //MARK: - MENU METHODS
    /*! This method creates a menu that will display results and will hold start button of the game*/
    func setupMenu() {
        
        let blurEffect = UIBlurEffect(style: UIBlurEffect.Style.extraLight)
        menu = UIVisualEffectView(effect: blurEffect)
        menu.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        self.view.addSubview(menu)
        menu.translatesAutoresizingMaskIntoConstraints = false
        menu.topAnchor.constraint(equalTo: self.view.topAnchor).isActive = true
        menu.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
        menu.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        menu.heightAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 1).isActive=true
        //Helper.attachTapGesture(&menu, target: self, action: #selector(menuHide))
        
        //Add a button and a label
        var playIcon = Paradigm.getTextLabel(CGRect(x: 0, y: 0, width: 10, height: 10), defaultText: "Play", minimumScaleFactor: 10, fontSizex: 18, fontName: Paradigm.signatureFontName)
        playIcon.contentMode = .center
        menu.contentView.addSubview(playIcon)
        playIcon.backgroundColor = UIColor.darkGray
        playIcon.textColor = UIColor.white
        playIcon.isUserInteractionEnabled = true
        playIcon.translatesAutoresizingMaskIntoConstraints = false
        playIcon.heightAnchor.constraint(equalToConstant: 60).isActive = true
        playIcon.trailingAnchor.constraint(equalTo: menu.trailingAnchor).isActive=true
        playIcon.leadingAnchor.constraint(equalTo: menu.leadingAnchor).isActive=true
        playIcon.centerXAnchor.constraint(equalTo: menu.centerXAnchor).isActive = true
        playIcon.centerYAnchor.constraint(equalTo: menu.centerYAnchor).isActive = true
        Paradigm.attachTapGesture(&playIcon, target: self, action: #selector(menuHide))
        
        
        //Label
        let mainScoreLabel = Paradigm.getTextLabel(defaultText: "Score: \(score)")
        mainScoreLabel.contentMode = .center
        menu.contentView.addSubview(mainScoreLabel)
        mainScoreLabel.translatesAutoresizingMaskIntoConstraints = false
        mainScoreLabel.leadingAnchor.constraint(equalTo: menu.leadingAnchor).isActive=true
        mainScoreLabel.trailingAnchor.constraint(equalTo: menu.trailingAnchor).isActive=true
        mainScoreLabel.heightAnchor.constraint(equalToConstant: 50).isActive=true
        mainScoreLabel.centerXAnchor.constraint(equalTo: menu.centerXAnchor).isActive=true
        mainScoreLabel.bottomAnchor.constraint(equalTo: playIcon.topAnchor, constant: -20).isActive=true
        menu.widthAnchor.constraint(equalToConstant: 60).isActive=true
        
    }
    
    func menuShow() {
        countDownTimer.invalidate()
        self.setupMenu()
        menuInDisplay = true
    }
    
    @objc func menuHide() {
        score = 0
        loadNewScene()
        menuInDisplay = false
        menu.removeFromSuperview()
    }
    
    //MARK: - ANSWER METHODS
    @objc func pressedButton(_ recognizer: UITapGestureRecognizer) {
        if let tag = recognizer.view?.tag {
            if(answer == options[tag]) {
                loadNewScene()
                score+=1
                scoreLabel.text = "\(score)"
            }else {
                menuShow()
            }
        }
    }
    
    
    /*! This method is for setting up Autolayouts for contents programmatically.
     1. There is a content view that will have all the elements
     2. There is an infoBarOne that is the top bar
     3. There is an infoBarTwo that will */
    func setupViews() {
        
        
        let contentView = UIView()
        contentView.backgroundColor = backgroundColor
        self.view.addSubview(contentView)
        contentView.translatesAutoresizingMaskIntoConstraints = false
        //Will have to work on a class - WDIL
        contentView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 30).isActive = true
        contentView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -30).isActive = true
        contentView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 10).isActive = true
        contentView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -10).isActive = true
        //
        
        //Set Background colors
        var infoBarOne = UIView()
        contentView.addSubview(infoBarOne)
        infoBarOne.backgroundColor = backgroundColor
        infoBarOne.translatesAutoresizingMaskIntoConstraints = false
        infoBarOne.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        infoBarOne.heightAnchor.constraint(equalToConstant: 50).isActive = true
        infoBarOne.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20).isActive=true
        infoBarOne.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20).isActive=true
        Paradigm.setShadow(_view: &infoBarOne)
        
        //Add a score card
        scoreLabel = Paradigm.getTextLabel(defaultText: "0")
        infoBarOne.addSubview(scoreLabel)
        scoreLabel.translatesAutoresizingMaskIntoConstraints = false
        scoreLabel.leadingAnchor.constraint(equalTo: infoBarOne.leadingAnchor).isActive=true
        scoreLabel.topAnchor.constraint(equalTo: infoBarOne.topAnchor).isActive=true
        scoreLabel.bottomAnchor.constraint(equalTo: infoBarOne.bottomAnchor).isActive=true
        scoreLabel.widthAnchor.constraint(equalToConstant: 60).isActive=true
        
        //Add a seperator
        let seperatorOne = UIView()
        seperatorOne.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
        infoBarOne.addSubview(seperatorOne)
        seperatorOne.translatesAutoresizingMaskIntoConstraints = false
        seperatorOne.topAnchor.constraint(equalTo: infoBarOne.topAnchor, constant: 15).isActive=true
        seperatorOne.bottomAnchor.constraint(equalTo: infoBarOne.bottomAnchor, constant: -15).isActive = true
        seperatorOne.widthAnchor.constraint(equalToConstant: 1).isActive = true
        seperatorOne.leadingAnchor.constraint(equalTo: scoreLabel.trailingAnchor).isActive = true
        
        
        //Add a questo
        countdownLabel = Paradigm.getTextLabel(defaultText: "60")
        infoBarOne.addSubview(countdownLabel)
        countdownLabel.translatesAutoresizingMaskIntoConstraints = false
        countdownLabel.trailingAnchor.constraint(equalTo: infoBarOne.trailingAnchor).isActive = true
        countdownLabel.topAnchor.constraint(equalTo: infoBarOne.topAnchor).isActive = true
        countdownLabel.bottomAnchor.constraint(equalTo: infoBarOne.bottomAnchor).isActive = true
        countdownLabel.widthAnchor.constraint(equalToConstant: 60).isActive = true
        
        //Add a seperator two and that should be it
        let seperatorTwo = UIView()
        seperatorTwo.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
        infoBarOne.addSubview(seperatorTwo)
        seperatorTwo.translatesAutoresizingMaskIntoConstraints = false
        seperatorTwo.topAnchor.constraint(equalTo: infoBarOne.topAnchor, constant: 15).isActive=true
        seperatorTwo.bottomAnchor.constraint(equalTo: infoBarOne.bottomAnchor, constant: -15).isActive = true
        seperatorTwo.widthAnchor.constraint(equalToConstant: 1).isActive = true
        seperatorTwo.trailingAnchor.constraint(equalTo: countdownLabel.leadingAnchor).isActive = true
        
        question = Paradigm.getTextLabel(defaultText: "Question")
        question.font = UIFont(name: Paradigm.commonFontName, size: 16)
        infoBarOne.addSubview(question)
        question.translatesAutoresizingMaskIntoConstraints = false
        question.trailingAnchor.constraint(equalTo: seperatorTwo.leadingAnchor).isActive = true
        question.leadingAnchor.constraint(equalTo: seperatorOne.trailingAnchor).isActive = true
        question.topAnchor.constraint(equalTo: infoBarOne.topAnchor).isActive = true
        question.bottomAnchor.constraint(equalTo: infoBarOne.bottomAnchor).isActive = true
        
        //Bottom Views
        var infoBarTwo = UIView()
        infoBarTwo.backgroundColor = UIColor.white
        contentView.addSubview(infoBarTwo)
        
        infoBarTwo.translatesAutoresizingMaskIntoConstraints = false
        infoBarTwo.widthAnchor.constraint(equalToConstant: 300).isActive=true
        infoBarTwo.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive=true
        infoBarTwo.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        infoBarTwo.heightAnchor.constraint(equalToConstant: 50).isActive=true
        Paradigm.setShadow(_view: &infoBarTwo)
        
        
        //Buttons
        var buttonOne = UIView()
        buttonOne.backgroundColor = UIColor.white
        infoBarTwo.addSubview(buttonOne)
        buttonOne.translatesAutoresizingMaskIntoConstraints = false
        buttonOne.leadingAnchor.constraint(equalTo: infoBarTwo.leadingAnchor).isActive=true
        buttonOne.topAnchor.constraint(equalTo: infoBarTwo.topAnchor).isActive=true
        buttonOne.bottomAnchor.constraint(equalTo: infoBarTwo.bottomAnchor).isActive=true
        buttonOne.widthAnchor.constraint(equalToConstant: 99).isActive=true
        buttonOne.tag = 0
        
        //Add a seperator
        let seperatorThree = UIView()
        seperatorThree.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
        infoBarTwo.addSubview(seperatorThree)
        seperatorThree.translatesAutoresizingMaskIntoConstraints = false
        seperatorThree.topAnchor.constraint(equalTo: infoBarTwo.topAnchor, constant: 15).isActive=true
        seperatorThree.bottomAnchor.constraint(equalTo: infoBarTwo.bottomAnchor, constant: -15).isActive = true
        seperatorThree.widthAnchor.constraint(equalToConstant: 1).isActive = true
        seperatorThree.leadingAnchor.constraint(equalTo: buttonOne.trailingAnchor).isActive = true
        
        var buttonThree = UIView()
        buttonThree.backgroundColor = UIColor.white
        infoBarTwo.addSubview(buttonThree)
        buttonThree.translatesAutoresizingMaskIntoConstraints = false
        buttonThree.trailingAnchor.constraint(equalTo: infoBarTwo.trailingAnchor).isActive=true
        buttonThree.topAnchor.constraint(equalTo: infoBarTwo.topAnchor).isActive=true
        buttonThree.bottomAnchor.constraint(equalTo: infoBarTwo.bottomAnchor).isActive=true
        buttonThree.widthAnchor.constraint(equalToConstant: 99).isActive=true
        buttonThree.tag = 2
        
        let seperatorFour = UIView()
        seperatorFour.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
        infoBarTwo.addSubview(seperatorFour)
        seperatorFour.translatesAutoresizingMaskIntoConstraints = false
        seperatorFour.topAnchor.constraint(equalTo: infoBarTwo.topAnchor, constant: 15).isActive=true
        seperatorFour.bottomAnchor.constraint(equalTo: infoBarTwo.bottomAnchor, constant: -15).isActive = true
        seperatorFour.widthAnchor.constraint(equalToConstant: 1).isActive = true
        seperatorFour.trailingAnchor.constraint(equalTo: buttonThree.leadingAnchor).isActive = true
        
        var buttonTwo = UIView()
        infoBarTwo.addSubview(buttonTwo)
        buttonTwo.translatesAutoresizingMaskIntoConstraints = false
        buttonTwo.trailingAnchor.constraint(equalTo: seperatorFour.leadingAnchor).isActive = true
        buttonTwo.leadingAnchor.constraint(equalTo: seperatorThree.trailingAnchor).isActive = true
        buttonTwo.topAnchor.constraint(equalTo: infoBarTwo.topAnchor).isActive = true
        buttonTwo.bottomAnchor.constraint(equalTo: infoBarTwo.bottomAnchor).isActive = true
        buttonTwo.tag = 1
        
        
        buttonLabelOne = Paradigm.getTextLabel(defaultText: "One")
        buttonOne.addSubview(buttonLabelOne)
        buttonLabelOne.translatesAutoresizingMaskIntoConstraints = false
        buttonLabelOne.trailingAnchor.constraint(equalTo: buttonOne.trailingAnchor).isActive = true
        buttonLabelOne.leadingAnchor.constraint(equalTo: buttonOne.leadingAnchor).isActive = true
        buttonLabelOne.topAnchor.constraint(equalTo: buttonOne.topAnchor).isActive = true
        buttonLabelOne.bottomAnchor.constraint(equalTo: buttonOne.bottomAnchor).isActive = true
        
        buttonLabelTwo = Paradigm.getTextLabel(defaultText: "Two")
        buttonTwo.addSubview(buttonLabelTwo)
        buttonLabelTwo.translatesAutoresizingMaskIntoConstraints = false
        buttonLabelTwo.trailingAnchor.constraint(equalTo: buttonTwo.trailingAnchor).isActive = true
        buttonLabelTwo.leadingAnchor.constraint(equalTo: buttonTwo.leadingAnchor).isActive = true
        buttonLabelTwo.topAnchor.constraint(equalTo: buttonTwo.topAnchor).isActive = true
        buttonLabelTwo.bottomAnchor.constraint(equalTo: buttonTwo.bottomAnchor).isActive = true
        
        buttonLabelThree = Paradigm.getTextLabel(defaultText: "Three")
        buttonThree.addSubview(buttonLabelThree)
        buttonLabelThree.translatesAutoresizingMaskIntoConstraints = false
        buttonLabelThree.trailingAnchor.constraint(equalTo: buttonThree.trailingAnchor).isActive = true
        buttonLabelThree.leadingAnchor.constraint(equalTo: buttonThree.leadingAnchor).isActive = true
        buttonLabelThree.topAnchor.constraint(equalTo: buttonThree.topAnchor).isActive = true
        buttonLabelThree.bottomAnchor.constraint(equalTo: buttonThree.bottomAnchor).isActive = true
        
        
        sceneView = game.scene3DObject.getSceneView(CGRect(x: 0, y: 0, width: 20, height: 20), allowsCameraControl: false, showStatistics: false, playing: true, scene: SCNScene(), delegate: nil)
        contentView.addSubview(sceneView)
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        sceneView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: 0).isActive = true
        sceneView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 0).isActive = true
        sceneView.topAnchor.constraint(equalTo: infoBarOne.bottomAnchor, constant: 10).isActive = true
        sceneView.bottomAnchor.constraint(equalTo: infoBarTwo.topAnchor, constant: -10).isActive = true
        
        Paradigm.attachTapGesture(&buttonOne, target: self, action: #selector(pressedButton(_:)))
        Paradigm.attachTapGesture(&buttonTwo, target: self, action: #selector(pressedButton(_:)))
        Paradigm.attachTapGesture(&buttonThree, target: self, action: #selector(pressedButton(_:)))
        
        self.setupMenu()
        
        self.view.layoutIfNeeded()
    }
    
}
