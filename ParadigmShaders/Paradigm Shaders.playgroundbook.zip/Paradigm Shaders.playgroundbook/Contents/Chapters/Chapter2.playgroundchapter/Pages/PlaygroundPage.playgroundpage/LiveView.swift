
import UIKit
import PlaygroundSupport

let view = ExperimentView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
//view.setupViews(shape, color: color, fresnelEffect: fresnelEffect, entryPoint: entryPoint, code: code, animateObject: animateObject, animationTime: animationTime)

//view.setupViews(expData.shape, color: expData.color, fresnelEffect: expData.fresnelEffect, entryPoint: expData.entryPoint, code: expData.code, animateObject: expData.animateObject, animationTime: expData.animationTime)

PlaygroundPage.current.liveView = view










