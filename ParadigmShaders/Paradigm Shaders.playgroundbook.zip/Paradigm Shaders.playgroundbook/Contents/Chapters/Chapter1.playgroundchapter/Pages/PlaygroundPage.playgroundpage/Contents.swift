/*:
 # Shaders in details
 
 This page is about exploring few textures and trying to understand how they work. There are multiple shader types that can be used in SceneKit. There are 10 shaders to explore. Circular Twister, Ripple, Toon, Glitch, Smoke, Complex Water Shader, Water, Rainbow and Complex Water with different texture.
 
 ![1](previousIcon@2x.png)
 This button is to go to a previous shader
 
 ![2](objectIcon@2x.png)
 This button is used to select a Geometry you want shader to get display on.
 
 ![3](colorIcon@2x.png)
 This button is used to take a picture from Camera
 
 ![4](infoIcon@2x.png)
 This button is used to get info about the shader
 
 ![5](animateIcon@2x.png)
 This button is used to toggle animations for the object. You can let it rotate or stop it from rotating
 
 ![6](arIcon@2x.png)
 This button is used to get into AR mode and see the scene in AR
 
 ![7](nextIcon@2x.png)
 This button is used to go to the next shader
 
 
 - Important: All the text data is from Apple documentation on these topics. It could take up to few seconds for the scene to load. **Please** wait until the scene appears.
 
 
 ## Introduction
 
 3D models are, essentially, a collection of 3D coordinates called vertices. They are connected together to make triangles. Each vertex can contain few other informations, such as a colour, the direction it points towards (called normal) and some coordinates to map textures onto it (called UV data). 3D models have a material and material has shaders.
 
 Models cannot be rendered without a material. Materials are wrappers which contain a shader and the values for its properties. Hence, different materials can share the same shader, feeding it with different data.
 Model->Material->Shader
 
 Shader functions run on the GPU.
 
 - Vertex Functions - Are used to play with vertex positions. For instance, animating an object.
 
 - Fragment Functions - Are used to change pixel colors.
 
 - Kernel Functions - Are used in Machine Learning and Kernel shaders are used for that.
 
 ## Types of Shaders?
 
 
 
 ## Shaders Integration in Scenekit?
 
 There are three levels of Metal shader integration with SceneKit.
 - SCNShadable
 - SCNProgram
 - SCNTechnique
 
 ## SCNShadable
 
 It is the easiest in to intergrate. SCNShadable is a protocol that all built in SCNGeometry objects conform to. SceneKit has an extensive library of primitive SCNGeometry objects that you may use individually or combined to create more complex shapes. This means that if you want to insert a small bit of Metal code to a cone or a plane, you can create one in SceneKit and inject shader code into the rendering pipeline without being responsible for setting up the whole thing.
 - SCNShaderModifierEntryPoint - corresponding to an entry point in SceneKit’s shader programs where you can attach a custom GPU shader code snippet.
 
 There are four different points.
 - Geometry
 - Surface
 - Lighting Model
 - Fragment
 
 ## SCNProgram
 
 Sometimes it is needed that you need a complete program to replace SceneKit's rendering of a geometry or material. You use an SCNProgram object to perform custom rendering using shader programs written in the Metal shading language or the OpenGL Shading Language (GLSL). A program object contains a vertex shader and a fragment shader. To use a program object for rendering, assign it to the program property of a geometry or material. Use a program object when you want to completely replace SceneKit’s rendering.
 
 ## SCNTechnique
 
 A specification for augmenting or postprocessing SceneKit's rendering of a scene using additional drawing passes with custom Metal or OpenGL shaders. It is a series of shaders that can be applied to your scene, specific groups of geometries or specific nodes or after your base shader. These shaders are called a ‘passes’ and carry an order, which is fundamental to the outcome
 
 
 
 Proceed to the [next page](@next) to get your hands dirty!
 */
