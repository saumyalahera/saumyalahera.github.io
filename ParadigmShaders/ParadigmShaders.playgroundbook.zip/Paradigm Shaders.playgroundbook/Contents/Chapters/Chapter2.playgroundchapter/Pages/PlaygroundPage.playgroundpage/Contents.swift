//#-hidden-code
import Foundation
import UIKit
import PlaygroundSupport
import SceneKit
let template = "if (_geometry.position.y > 0.0) {_geometry.position.xz += vec2(0.5 * sin(3.0 * u_time),0.5 * cos(3.0 * u_time)) * (u_time < 3.0 ? u_time / 3.0 : 1.0);}"
//#-end-hidden-code
/*:
 # Experiment
 
 This page covers the concept of Shader Modifiers. As you can create your own snippet and attach it to a geometry and that is fun! Get your hands dirty. Create and play with the shader properties.
 
 
 - Important: It only covers SNNShadable because it is easy and add snippets. Structures provided are from Apple Documentation
 
 # Document
 
 You can select properties for your code and just add a snippet to them. Also keep in mind that if the code snippet has errors, the material will appear pink. But it is good to explore things on your own. Dont get afraid to get an error. It is a good sign that you are exploring and exploring may have difficulties and failure is the key to success!
 
 ### Shapes
 - Cube
 - Sphere
 - Pyramid
 - Torus
 - Cylinder
 
 
 ###
 ### Colors
 - Red
 - Blue
 - Yellow
 - Black
 - Green
 
 
 ### Fresnel Effect
 - It is a boolean so it is upon you
 
 
 ### Shader Entry Points
 - .geometry
 - .lightingModel
 - .fragment
 - .surface
 
 
 ### Code
 - Write your own code
 - Enjoy
 
 
 ### Animate Object
 - It is a boolean so it is upon you
 
 
 ### Animation Speed
 - Basically it is a time value. Greater the value, more time it takes to animate
 
 ## Details
 
 ### Geometry - SCNShaderGeometry (_geometry)
 
 Shader modifiers for this entry point execute in the vertex processing stage.
 The geometry entry point declares the following structure:
 
 - vec3 position
 - vec3 normal
 - vec4 tangent
 - vec2 texcoords[kSCNTexcoordCount]
 
 
 ### Surface - SCNShaderSurface (_surface)
 Shader modifiers for this entry point execute in the fragment processing stage.
 The surface entry point defines the following structure:
 
 - vec3 view;                // Direction from the point on the surface toward the camera (V)
 - vec3 position;            // Position of the fragment
 - vec3 normal;              // Normal of the fragment (N)
 - vec3 tangent;             // Tangent of the fragment
 - vec3 bitangent;           // Bitangent of the fragment
 - vec4 ambient;             // Ambient property of the fragment
 - vec2 ambientTexcoord;     // Ambient texture coordinates
 - vec4 diffuse;             // Diffuse property of the fragment. Alpha contains the opacity.
 - vec2 diffuseTexcoord;     // Diffuse texture coordinates
 - vec4 specular;            // Specular property of the fragment
 - vec2 specularTexcoord;    // Specular texture coordinates
 - vec4 emission;            // Emission property of the fragment
 - vec2 emissionTexcoord;    // Emission texture coordinates
 - vec4 multiply;            // Multiply property of the fragment
 - vec2 multiplyTexcoord;    // Multiply texture coordinates
 - vec4 transparent;         // Transparent property of the fragment
 - vec2 transparentTexcoord; // Transparent texture coordinates
 - vec4 reflective;          // Reflective property of the fragment
 - float shininess;          // Shininess property of the fragment.
 - float fresnel;            // Fresnel property of the fragment.
 
 ###
 ###
 ### LightingModel - SCNShaderLightingContribution (_lightingContribution)
 
 Shader modifiers for this entry point may execute in either the vertex or fragment processing stage. If the litPerPixel property of a material affected by the shader modifier is true, the snippet executes in the fragment processing stage; otherwise the snippet executes in the vertex processing stage.
 The surface entry point defines the following structures:
 
 - vec3 ambient;
 - vec3 diffuse;
 - vec3 specular;
 
 ### LightingModel - SCNShaderLight (_light)
 
 - vec4 intensity;
 - vec3 direction; // Direction from the point on the surface toward the light
 
 ### Fragment - SCNShaderOutput (_output)
 
 Shader modifiers for this entry point execute in the fragment processing stage.
 The fragment entry point defines the following structure:
 
 - vec4 color;
 
 #
 # Code
 
 Please give a shape
 */
let shape = /*#-editable-code*/Shapes.Cube/*#-end-editable-code*/

/*:
 Select a color for your geometry
 */
let color = /*#-editable-code*/Colors.Green/*#-end-editable-code*/

/*:
 Do you like Fresnel Effect?
 */
let fresnelEffect = /*#-editable-code*/true/*#-end-editable-code*/

/*:
 Select an EntryPoint for your geometry
 */
let entryPoint = /*#-editable-code*/SCNShaderModifierEntryPoint.geometry/*#-end-editable-code*/

/*:
 Add your code snippet
 */
let code = /*#-editable-code*/template/*#-end-editable-code*/

/*:
 Want to animate the object?
 */
let animateObject = /*#-editable-code*/false/*#-end-editable-code*/

/*:
 If yes, can you give an interval?
 */
let animationTime:Double = /*#-editable-code*/12/*#-end-editable-code*/


//#-hidden-code
var entryPointString = "Geometry"
 if(entryPoint == SCNShaderModifierEntryPoint.fragment) {
    entryPointString = "Fragment"
 }else if(entryPoint == SCNShaderModifierEntryPoint.surface) {
    entryPointString = "Surface"
 }else if(entryPoint == SCNShaderModifierEntryPoint.lightingModel) {
    entryPointString = "Light"
 }

let page = PlaygroundPage.current
let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
let command: PlaygroundValue
command = .dictionary([
    "Shape": .string("\(shape)"),
    "Color": .string("\(color)"),
    "FresnelEffect": .boolean(fresnelEffect),
    "EntryPoint": .string("\(entryPointString)"),
    "Code": .string("\(code)"),
    "AnimateObject": .boolean(animateObject),
    "AnimateTime": .floatingPoint(animationTime)
    ])

proxy.send(command)
//#-end-hidden-code
