import Foundation
import SceneKit
import PlaygroundSupport


let scene3DObjectExperiment = Scene3D()

public var expData = Experiment(shape: Shapes.Cube, color: Colors.Green, fresnelEffect: true, entryPoint: .geometry, code: "", animateObject:false, animateTime: 10)

public enum Shapes:String {
    case Cube = "Cube"
    case Sphere = "Sphere"
    case Pyramid = "Pyramid"
    case Torus = "Torus"
    case Cylinder = "Cylinder"
}


public enum Colors:String {
    case Red = "Red"
    case Blue = "Blue"
    case Yellow = "Yellow"
    case Black = "Black"
    case Green = "Green"
}


public class ExperimentView: UIView {
    
    


    /*This method is used to override*/
    public override init(frame: CGRect) {
        super.init(frame: frame)
        //setup methods
        //self.delegate = self as! PlaygroundLiveViewMessageHandler
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //It is time to code
    /*! This function is there to setup first scene.
     1. It has a Cylinder with a Glitch Shader on it.
     2. Cylinder also rotates*/
    public func setupScene(_ shape: Shapes, color: Colors, fresnelEffect:Bool, entryPoint: SCNShaderModifierEntryPoint, code:String, animateObject: Bool, animationTime: Double) -> SCNScene {
        
        
        //Basic scene setup
        let scene = scene3DObject.getScene(nil)
        //sceneView = scene3DObject.getSceneView(frame, allowsCameraControl: false, showStatistics: false, playing: true, scene: scene, delegate: nil)
        
        
        //Get camera node
        let camera = scene3DObject.getCamera()
        var cameraNode = scene3DObject.getCameraWithNode(camera, position: SCNVector3(x: -2, y: 2, z: 4))
        
        //Get light node
        let light = scene3DObject.getLight()
        var lightNode = scene3DObject.getLightNode(light, position: SCNVector3(x: 1.5, y: 1.5, z: 1.5))
        
        
        /*EXPS STARTS*/
        //Create nodes
        let color = scene3DObject.getColorFromColorString(color.rawValue)
        
        var shadermodifier = NSMutableDictionary()
        scene3DObject.attachEntryPointFromString(&shadermodifier, entrypoint: entryPoint, code: code)
        let material = scene3DObject.getMaterial(color, shaders: shadermodifier, fresnelEffect: fresnelEffect)
        let node = scene3DObject.getNodeFromString(shape.rawValue, materials: material)
        
        
        //Rotate it forever
        if(animateObject) {
            let action = SCNAction.rotateBy(x: 0, y: CGFloat(GLKMathDegreesToRadians(360)), z: 0, duration: animationTime)
            let rotateAlltime = SCNAction.repeatForever(action)
            node.runAction(rotateAlltime)
        }
        
        //3D constraints
        let lookAtConstraints = scene3DObject.getLookConstraint(node)
        scene3DObject.attachLookConstraint(&cameraNode, constraints: lookAtConstraints)
        scene3DObject.attachLookConstraint(&lightNode, constraints: lookAtConstraints)
        
        //Add them to the scene
        scene.rootNode.addChildNode(lightNode)
        scene.rootNode.addChildNode(cameraNode)
        scene.rootNode.addChildNode(node)
        return scene
    }
    
    public func getRawGeometryValues(_ text: String) -> Shapes {
        if let shape = Shapes.init(rawValue: text) {
            return shape
        }else {
            return Shapes.Cube
        }
       
    }
    
    public func getRawColorValues(_ text:String) -> Colors {
        if let shape = Colors.init(rawValue: text) {
            return shape
        }else {
            return Colors.Green
        }
    }
    
    public func getRawEntryPoint(_ text:String) -> SCNShaderModifierEntryPoint {
        var entryPoint = SCNShaderModifierEntryPoint.geometry
        if(text == "Light") {
            entryPoint = .lightingModel
        }else if(text == "Fragment") {
            entryPoint = .fragment
        }else if(text == "Surface") {
            entryPoint = .surface
        }
        return entryPoint
    }
    
    public func setupViews(_ shape: Shapes, color: Colors, fresnelEffect:Bool, entryPoint: SCNShaderModifierEntryPoint, code:String, animateObject: Bool, animationTime: Double) {
        
        self.backgroundColor = UIColor.white
        //Add content view
        let contentView = UIView()
        contentView.backgroundColor = backgroundColor
        self.addSubview(contentView)
        contentView.translatesAutoresizingMaskIntoConstraints = false
        //Will have to work on a class - WDIL
        contentView.heightAnchor.constraint(equalToConstant: 400).isActive = true
        contentView.widthAnchor.constraint(equalToConstant: 400).isActive = true
        contentView.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        contentView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        
        //Label - CAN PARADIGM
        let label = Paradigm.getTextLabel(CGRect(x: 0, y: 0, width: 10, height: 10), defaultText: "Experiment", minimumScaleFactor: 10, fontSizex: 18, fontName: Paradigm.signatureFontName)
        contentView.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 0).isActive = true
        label.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: 0).isActive = true
        label.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        label.heightAnchor.constraint(equalToConstant: 40).isActive = true
        label.backgroundColor = backgroundColor
        
        //SceneView
        let sceneView = scene3DObject.getSceneView(CGRect(x: 0, y: 0, width: 100, height: 100), allowsCameraControl: false, showStatistics: false, playing: true, scene: setupScene(shape, color: color, fresnelEffect: fresnelEffect, entryPoint: entryPoint, code: code, animateObject: animateObject, animationTime: animationTime), delegate: nil)
        contentView.addSubview(sceneView)
        sceneView.isPlaying = true
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        sceneView.topAnchor.constraint(equalTo: self.topAnchor, constant: 5).isActive = true
        sceneView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 0).isActive = true
        sceneView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: 0).isActive = true
        sceneView.bottomAnchor.constraint(equalTo: label.topAnchor).isActive = true
        
    }
    
    
}

extension ExperimentView:PlaygroundLiveViewMessageHandler {
    
    public func receive(_ message: PlaygroundValue) {
       
        self.backgroundColor = UIColor.black
        
        //Parsing all the data and that will make things crazy
        switch message {
        
        case let .dictionary(dictionary):
            
            if case let .string(message)? = dictionary["Color"] {
                expData.color = self.getRawColorValues(message)
            }
            
            if case let .string(message)? = dictionary["Shape"] {
                expData.shape = self.getRawGeometryValues(message)
            }
            
            if case let .boolean(message)? = dictionary["FresnelEffect"] {
                expData.fresnelEffect = message
            }
            
            if case let .string(message)? = dictionary["EntryPoint"] {
                expData.entryPoint = self.getRawEntryPoint(message)
            }
            
            if case let .string(message)? = dictionary["Code"] {
                expData.code = message
            }
            
            if case let .boolean(message)? = dictionary["AnimateObject"] {
                expData.animateObject = message
            }
            
            if case let .floatingPoint(message)? = dictionary["AnimateTime"] {
                expData.animateTime = message
            }
            
            
        default:
            print("Nothing to process")
        }
        
        
        
        self.setupViews(expData.shape, color: expData.color, fresnelEffect: expData.fresnelEffect, entryPoint: expData.entryPoint, code: expData.code, animateObject: expData.animateObject, animationTime: expData.animateTime)
    
    }
}

/*  This is required to store data that will be used to store data*/
public struct Experiment {
    var shape:Shapes!
    var color:Colors!
    var fresnelEffect:Bool!
    var entryPoint:SCNShaderModifierEntryPoint!
    var code:String!
    var animateObject:Bool!
    var animateTime:Double!
}




