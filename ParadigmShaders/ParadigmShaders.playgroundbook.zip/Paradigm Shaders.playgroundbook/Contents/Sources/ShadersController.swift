//
//  CreateShadersController.swift
//  SaumyaGraphics
//
//  Created by Saumya Lahera on 22/03/19.
//  Copyright © 2019 Saumya Lahera. All rights reserved.
//

import UIKit
import SceneKit
import ARKit

public var scene3DObjectShaders = Scene3D()
public var scene2DObject = Scene2D()

//MARK: - STRUCTURE
/*! This structure is used to store properties of a current editable object on a screen*/
public struct CustomShader {
    var name:String!
    var material:SCNMaterial!
    var note:String!
}

public class ShadersController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    /// Create a scene view
    var sceneView:SCNView!
    
    /// Create an ARScene. This will be used to display 3D Object on the screen
    var arSceneView:ARSCNView!
    let arConfiguration = ARWorldTrackingConfiguration()
    
    /// ARView
    var arViewHeightConstraint:NSLayoutConstraint!
    
    /// Current Objects
    var currentColor = "Red"
    var currentShape = "Cube"
    var currentAnimationStatus = false
    
    /// Current Information TextView
    var shaderInformationTextView = UITextView()
    
    /// These are predefined Shaders
    var materials = [CustomShader]()
    
    /// Shader Current Index
    var shaderIndex = 0
    
    /*! This option is to keep the track of what button is pressed
     1. 0 - Objects
     2. 1 - Shader Modifiers
     3. 2 - Shader Modifier Options*/
    var currentOption = 0
    
    /// Content View
    var contentViewHeightConstraint:NSLayoutConstraint!
    
    /// Background
    let backgroundColor = UIColor.white
    
    /// Current Node
    var label:UILabel!
    
    ///Scene Label Title
    lazy var labelTitle = "Circular"
    
    ///Shader Title
    var shaderInfoTitleLabel = UILabel()
    
    /// Suboptions View
    var subOptionsViewHeightConstraint:NSLayoutConstraint!
    
    /// Code Editor View
    var codeEditorHeightConstraint:NSLayoutConstraint!
    
    /// TableView Options
    var subOptionsTableView:UITableView!
    
    /// Object animation speed
    var animationSpeed:Double = 12
    
    /// Predefined Options
    var objects = ["Sphere","Cube","Cylinder","Pyramid"]
    var colors = ["Red","Green","Black","Blue","Yellow"]
    
    /// Current Table Options based on the options you select
    var currentTableOptions = [String]()
    
    /// ImageView for animation because that will change the whole thing in here
    var optionFive = UIImageView()
    
    
    //var currentNodeOptions:Node!
    
    //MARK: - UIVIEWCONTROLLER
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.setupCreateShaders()
        self.view.backgroundColor = backgroundColor
    }
    
    
    
    //MARK: - SHADERS
    /*! This method is the most important method because it stores information about shaders
     1. Material
     2. Shader Modifier
     3. Shader Type*/
    func setupMaterials() {
        
        var shaderName = "Circular"
        var shaderModifier = NSMutableDictionary()
        var nodeMaterial:SCNMaterial?
        
        //Circular Cube
        scene3DObject.attachEntryPointFromFile(&shaderModifier, entrypoint: .geometry, name: shaderName, type: "shader")
        nodeMaterial = scene3DObject.getMaterial(.red, shaders: shaderModifier, fresnelEffect: true)
        materials.append(CustomShader(name: shaderName, material: nodeMaterial!, note: Paradigm.getShader(from: "Circular", extension_x: "shader")))
        
        //Toon shader
        shaderName = "Twister"
        shaderModifier = NSMutableDictionary()
        scene3DObject.attachEntryPointFromFile(&shaderModifier, entrypoint: .geometry, name: shaderName, type: "shader")
        nodeMaterial = scene3DObject.getMaterial(.blue, shaders: shaderModifier, fresnelEffect: true)
        materials.append(CustomShader(name: shaderName, material: nodeMaterial!, note: Paradigm.getShader(from: "Twister", extension_x: "shader")))
        
        //Twisted
        shaderName = "Ripple"
        shaderModifier = NSMutableDictionary()
        scene3DObject.attachEntryPointFromFile(&shaderModifier, entrypoint: .geometry, name: shaderName, type: "shader")
        nodeMaterial = scene3DObject.getMaterial(.green, shaders: shaderModifier, fresnelEffect: true)
        materials.append(CustomShader(name: shaderName, material: nodeMaterial!, note: Paradigm.getShader(from: "Ripple", extension_x: "shader")))
        
        //Twisted
        shaderName = "Toon"
        shaderModifier = NSMutableDictionary()
        scene3DObject.attachEntryPointFromFile(&shaderModifier, entrypoint: .lightingModel, name: shaderName, type: "shader")
        nodeMaterial = scene3DObject.getMaterial(.red, shaders: shaderModifier, fresnelEffect: false)
        materials.append(CustomShader(name: shaderName, material: nodeMaterial!, note: Paradigm.getShader(from: "Toon", extension_x: "shader")))
        
        
        //Glitch Shader
        nodeMaterial = scene3DObject.getMaterial(shaders: nil)
        scene3DObject.attachShaderPrograms(&nodeMaterial, fragment_function: "glitchFragment", vertex_function: "glitchVertex", file: "GlitchShader")
        scene3DObject.attachTextureToMaterial(&nodeMaterial, imageName: "newyork.png", key: "diffuseTexture")
        materials.append(CustomShader(name: "Glitch", material: nodeMaterial!, note: Paradigm.getShader(from: "GlitchShader", extension_x: "metal")))
        
        //Smoke Shader
        nodeMaterial = scene3DObject.getMaterial(shaders: nil)
        scene3DObject.attachShaderPrograms(&nodeMaterial, fragment_function: "smokeFragment", vertex_function: "smokeVertex", file: "SmokeShader")
        materials.append(CustomShader(name: "Smoke", material: nodeMaterial!, note: Paradigm.getShader(from: "SmokeShader", extension_x: "metal")))
        
        //Complex Water Shader
        nodeMaterial = scene3DObject.getMaterial(shaders: nil)
        scene3DObject.attachShaderPrograms(&nodeMaterial, fragment_function: "complexWaterFragment", vertex_function: "complexWaterVertex", file: "ComplexWaterShader")
        scene3DObject.attachTextureToMaterial(&nodeMaterial, imageName: "apple2.png", key: "textureOne")
        scene3DObject.attachTextureToMaterial(&nodeMaterial, imageName: "newyork.png", key: "textureTwo")
        materials.append(CustomShader(name: "Complex Water", material: nodeMaterial!, note: Paradigm.getShader(from: "ComplexWaterShader", extension_x: "metal")))
        
        //Water Shader
        //let saumya2d = Saumya2D()
        nodeMaterial = scene3DObject.getMaterial(shaders: nil)
        //node = scene3DObject.getSphereWithNode(materials: nil)
        //node.geometry?.firstMaterial?.diffuse.contents = saumya2d.getScene(CGRect(x: 0, y: 0, width: 600, height: 600))
        materials.append(CustomShader(name: "Water2D", material: nodeMaterial!, note: Paradigm.getShader(from: "Liquid2DShader", extension_x: "fsh")))
        
        
        //Rainbow shader
        nodeMaterial = scene3DObject.getMaterial(shaders: nil)
        scene3DObject.attachShaderPrograms(&nodeMaterial, fragment_function: "rainbowPaintingFragment", vertex_function: "rainbowPaintingVertex", file: "RainbowPaintingShader")
        materials.append(CustomShader(name: "Rainbow Painting", material: nodeMaterial!, note: Paradigm.getShader(from: "RainbowPaintingShader", extension_x: "metal")))
        
        //Complex Water 2
        nodeMaterial = scene3DObject.getMaterial(shaders: nil)
        scene3DObject.attachShaderPrograms(&nodeMaterial, fragment_function: "complexWaterFragment", vertex_function: "complexWaterVertex", file: "ComplexWaterShader")
        scene3DObject.attachTextureToMaterial(&nodeMaterial, imageName: "noise.jpg", key: "textureOne")
        scene3DObject.attachTextureToMaterial(&nodeMaterial, imageName: "pebbles.jpg", key: "textureTwo")
        materials.append(CustomShader(name: "Complex Noise", material: nodeMaterial!, note: Paradigm.getShader(from: "ComplexWaterShader", extension_x: "metal")))
        
    }
    
    /*! This function is there to setup scene.
     - Everytime you select an option this function gets called and changes the scene
     - Basically there are two properties top be taken care of.
     1. Current Shape
     2. Current Color*/
    public func setupScene(shader:CustomShader, color:String, shape:String, nodeAnimating:Bool) -> SCNScene{
        
        //Basic scene setup
        let scene = scene3DObject.getScene(nil)
        //sceneView = scene3DObject.getSceneView(frame, allowsCameraControl: false, showStatistics: false, playing: true, scene: scene, delegate: nil)
        
        //Get camera node
        let camera = scene3DObject.getCamera()
        var cameraNode = scene3DObject.getCameraWithNode(camera, position: SCNVector3(x: -2, y: 2, z: 2))
        
        //Get light node
        let light = scene3DObject.getLight(.directional)
        var lightNode = scene3DObject.getLightNode(light, position: SCNVector3(x: 1.5, y: 1.5, z: 1.5))
        
        //Material
        let material = shader.material
        print("currentColor: \(currentColor)")
        material?.diffuse.contents = scene3DObject.getColorFromColorString(currentColor)
        let currentNode = scene3DObject.getNodeFromString(currentShape, materials: material)
        
        if(shader.name == "Water2D") {
            // public func getScene(_ frame: CGRect, texture: String, shader: String) -> SKScene
            currentNode.geometry?.firstMaterial?.diffuse.contents = scene2DObject.getScene(CGRect(x: 0, y: 0, width: 600, height: 600), texture: "newyork.png", shader: "Liquid2DShader")
        }
        
        //Rotate it forever
        currentNode.removeAllActions()
        if(nodeAnimating) {
            let action = SCNAction.rotateBy(x: 0, y: CGFloat(GLKMathDegreesToRadians(360)), z: 0, duration: animationSpeed)
            let rotateAlltime = SCNAction.repeatForever(action)
            currentNode.runAction(rotateAlltime)
        }
        
        //3D constraints
        let lookAtConstraints = scene3DObject.getLookConstraint(currentNode)
        scene3DObject.attachLookConstraint(&cameraNode, constraints: lookAtConstraints)
        scene3DObject.attachLookConstraint(&lightNode, constraints: lookAtConstraints)
        
        //Add them to the scene
        scene.rootNode.addChildNode(lightNode)
        scene.rootNode.addChildNode(cameraNode)
        scene.rootNode.addChildNode(currentNode)
        
        //label.text = shader.name
        return scene
    }
    
    /*! This method is used to add objects to the ARKit. This is just a test function that will be used to make
     - This takes the same arguments as in to create SceneKit scene object
     - This is placed onto a ARView*/
    func setupARObject(shader:CustomShader, color:String, shape:String, nodeAnimating:Bool) {
        
        let material = shader.material
        material?.diffuse.contents = scene3DObject.getColorFromColorString(currentColor)
        let currentNode = scene3DObject.getNodeFromString(currentShape, materials: material)
        
        if(shader.name == "Water2D") {
            currentNode.geometry?.firstMaterial?.diffuse.contents = scene2DObject.getScene(CGRect(x: 0, y: 0, width: 600, height: 600), texture: "newyork.png", shader: "Liquid2DShader")
        }
        
        //Rotate it forever
        currentNode.removeAllActions()
        if(nodeAnimating) {
            let action = SCNAction.rotateBy(x: 0, y: CGFloat(GLKMathDegreesToRadians(360)), z: 0, duration: animationSpeed)
            let rotateAlltime = SCNAction.repeatForever(action)
            currentNode.runAction(rotateAlltime)
        }
        
        //Add objects to the sceneview
        let scene = SCNScene()
        scene.rootNode.addChildNode(currentNode)
        arSceneView.scene=scene
        
    }
    
    //MARK: - AUTOLAYOUT METHODS
    /*! Setup objects because */
    func setupCreateShaders() {
        
        self.setupMaterials()
        
        //Basic setu
        /*let material = materials[shaderIndex].material
         material?.diffuse.contents = [scene3DObject.getColorFromColorString(currentColor)]
         currentNode = scene3DObject.getNodeFromString(currentShape, materials: material)*/
        //self.setupScene(nodeAnimating: true)
        
        let contentView = UIView()
        contentView.backgroundColor = backgroundColor
        self.view.addSubview(contentView)
        contentView.translatesAutoresizingMaskIntoConstraints = false
        //Will have to work on a class - WDIL
        contentViewHeightConstraint = contentView.heightAnchor.constraint(equalToConstant: 400)
        contentViewHeightConstraint.isActive = true
        contentView.widthAnchor.constraint(equalToConstant: 400).isActive = true
        contentView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        contentView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        
        //Add options view
        var optionsView = UIView()
        contentView.addSubview(optionsView)
        optionsView.backgroundColor = backgroundColor
        optionsView.translatesAutoresizingMaskIntoConstraints = false
        optionsView.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        optionsView.widthAnchor.constraint(equalToConstant: 356).isActive = true
        optionsView.heightAnchor.constraint(equalToConstant: 40).isActive = true
        optionsView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor).isActive = true
        optionsView.layer.cornerRadius = 20
        Paradigm.setShadow(_view: &optionsView, _shadowColor: UIColor.lightGray, _opacity: 0.4, _cornerRadius: 20)
        
        //Label - CAN PARADIGM
        label = Paradigm.getTextLabel(CGRect(x: 0, y: 0, width: 10, height: 10), defaultText: labelTitle, minimumScaleFactor: 10, fontSizex: 18, fontName: Paradigm.signatureFontName)
        contentView.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 0).isActive = true
        label.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: 0).isActive = true
        label.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        label.heightAnchor.constraint(equalToConstant: 40).isActive = true
        label.backgroundColor = backgroundColor
        
        //SceneView
        sceneView = scene3DObject.getSceneView(CGRect(x: 0, y: 0, width: 100, height: 100), allowsCameraControl: false, showStatistics: false, playing: true, scene: self.setupScene(shader: materials[shaderIndex], color: currentColor, shape: currentShape, nodeAnimating: false), delegate: nil)
        sceneView.isPlaying = true
        //sceneView.delegate = self
        contentView.addSubview(sceneView)
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        sceneView.topAnchor.constraint(equalTo: optionsView.bottomAnchor, constant: 10).isActive = true
        sceneView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 0).isActive = true
        sceneView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: 0).isActive = true
        sceneView.bottomAnchor.constraint(equalTo: label.topAnchor).isActive = true
        
        let widthK:CGFloat = 50
        
        //ADD ELEMENTS TO INFOBAR
        var optionOne = UIImageView(image: UIImage(named: "previousIcon@2x.png"))
        optionsView.addSubview(optionOne)
        optionOne.contentMode = .center
        optionOne.isUserInteractionEnabled = true
        optionOne.translatesAutoresizingMaskIntoConstraints = false
        optionOne.leadingAnchor.constraint(equalTo: optionsView.leadingAnchor).isActive = true
        optionOne.topAnchor.constraint(equalTo: optionsView.topAnchor).isActive = true
        optionOne.widthAnchor.constraint(equalToConstant: widthK).isActive = true
        optionOne.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor).isActive = true
        Paradigm.attachTapGesture(&optionOne, target: self, action: #selector(optionOneMethod))
        
        let b1 = UIView()
        optionsView.addSubview(b1)
        b1.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
        b1.translatesAutoresizingMaskIntoConstraints = false
        b1.topAnchor.constraint(equalTo: optionsView.topAnchor, constant: 15).isActive=true
        b1.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor, constant: -15).isActive = true
        b1.widthAnchor.constraint(equalToConstant: 1).isActive = true
        b1.leadingAnchor.constraint(equalTo: optionOne.trailingAnchor).isActive = true
        
        var optionTwo = UIImageView(image: UIImage(named: "objectIcon@2x.png"))
        optionsView.addSubview(optionTwo)
        optionTwo.contentMode = .center
        optionTwo.isUserInteractionEnabled = true
        optionTwo.translatesAutoresizingMaskIntoConstraints = false
        optionTwo.leadingAnchor.constraint(equalTo: b1.leadingAnchor).isActive = true
        optionTwo.topAnchor.constraint(equalTo: optionsView.topAnchor).isActive = true
        optionTwo.widthAnchor.constraint(equalToConstant: widthK).isActive = true
        optionTwo.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor).isActive = true
        Paradigm.attachTapGesture(&optionTwo, target: self, action: #selector(optionTwoMethod))
        
        let b2 = UIView()
        optionsView.addSubview(b2)
        b2.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
        b2.translatesAutoresizingMaskIntoConstraints = false
        b2.topAnchor.constraint(equalTo: optionsView.topAnchor, constant: 15).isActive=true
        b2.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor, constant: -15).isActive = true
        b2.widthAnchor.constraint(equalToConstant: 1).isActive = true
        b2.leadingAnchor.constraint(equalTo: optionTwo.trailingAnchor).isActive = true
        
        var optionThree = UIImageView(image: UIImage(named: "colorIcon@2x.png"))
        optionsView.addSubview(optionThree)
        optionThree.contentMode = .center
        optionThree.isUserInteractionEnabled = true
        optionThree.translatesAutoresizingMaskIntoConstraints = false
        optionThree.leadingAnchor.constraint(equalTo: b2.leadingAnchor).isActive = true
        optionThree.topAnchor.constraint(equalTo: optionsView.topAnchor).isActive = true
        optionThree.widthAnchor.constraint(equalToConstant: widthK).isActive = true
        optionThree.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor).isActive = true
        Paradigm.attachTapGesture(&optionThree, target: self, action: #selector(optionThreeMethod))
        
        let b3 = UIView()
        optionsView.addSubview(b3)
        b3.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
        b3.translatesAutoresizingMaskIntoConstraints = false
        b3.topAnchor.constraint(equalTo: optionsView.topAnchor, constant: 15).isActive=true
        b3.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor, constant: -15).isActive = true
        b3.widthAnchor.constraint(equalToConstant: 1).isActive = true
        b3.leadingAnchor.constraint(equalTo: optionThree.trailingAnchor).isActive = true
        
        var optionFour = UIImageView(image: UIImage(named: "infoIcon@2x.png"))
        optionsView.addSubview(optionFour)
        optionFour.contentMode = .center
        optionFour.isUserInteractionEnabled = true
        optionFour.translatesAutoresizingMaskIntoConstraints = false
        optionFour.leadingAnchor.constraint(equalTo: b3.leadingAnchor).isActive = true
        optionFour.topAnchor.constraint(equalTo: optionsView.topAnchor).isActive = true
        optionFour.widthAnchor.constraint(equalToConstant: widthK).isActive = true
        optionFour.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor).isActive = true
        Paradigm.attachTapGesture(&optionFour, target: self, action: #selector(optionFourMethod))
        
        let b4 = UIView()
        optionsView.addSubview(b4)
        b4.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
        b4.translatesAutoresizingMaskIntoConstraints = false
        b4.topAnchor.constraint(equalTo: optionsView.topAnchor, constant: 15).isActive=true
        b4.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor, constant: -15).isActive = true
        b4.widthAnchor.constraint(equalToConstant: 1).isActive = true
        b4.leadingAnchor.constraint(equalTo: optionFour.trailingAnchor).isActive = true
        
        optionFive = UIImageView(image: UIImage(named: "stopAnimateIcon@2x.png"))
        optionsView.addSubview(optionFive)
        optionFive.contentMode = .center
        optionFive.isUserInteractionEnabled = true
        optionFive.translatesAutoresizingMaskIntoConstraints = false
        optionFive.leadingAnchor.constraint(equalTo: b4.leadingAnchor).isActive = true
        optionFive.topAnchor.constraint(equalTo: optionsView.topAnchor).isActive = true
        optionFive.widthAnchor.constraint(equalToConstant: widthK).isActive = true
        optionFive.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor).isActive = true
        Paradigm.attachTapGesture(&optionFive, target: self, action: #selector(optionFiveMethod))
        
        let b5 = UIView()
        optionsView.addSubview(b5)
        b5.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
        b5.translatesAutoresizingMaskIntoConstraints = false
        b5.topAnchor.constraint(equalTo: optionsView.topAnchor, constant: 15).isActive=true
        b5.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor, constant: -15).isActive = true
        b5.widthAnchor.constraint(equalToConstant: 1).isActive = true
        b5.leadingAnchor.constraint(equalTo: optionFive.trailingAnchor).isActive = true
        
        var optionSix = UIImageView(image: UIImage(named: "arIcon@2x.png"))
        optionsView.addSubview(optionSix)
        optionSix.contentMode = .center
        optionSix.isUserInteractionEnabled = true
        optionSix.translatesAutoresizingMaskIntoConstraints = false
        optionSix.leadingAnchor.constraint(equalTo: b5.leadingAnchor).isActive = true
        optionSix.topAnchor.constraint(equalTo: optionsView.topAnchor).isActive = true
        optionSix.widthAnchor.constraint(equalToConstant: widthK).isActive = true
        optionSix.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor).isActive = true
        Paradigm.attachTapGesture(&optionSix, target: self, action: #selector(optionSixMethod))
        
        let b6 = UIView()
        optionsView.addSubview(b6)
        b6.backgroundColor = UIColor.lightGray.withAlphaComponent(0.3)
        b6.translatesAutoresizingMaskIntoConstraints = false
        b6.topAnchor.constraint(equalTo: optionsView.topAnchor, constant: 15).isActive=true
        b6.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor, constant: -15).isActive = true
        b6.widthAnchor.constraint(equalToConstant: 1).isActive = true
        b6.leadingAnchor.constraint(equalTo: optionSix.trailingAnchor).isActive = true
        
        var optionSeven = UIImageView(image: UIImage(named: "nextIcon@2x.png"))
        optionsView.addSubview(optionSeven)
        optionSeven.contentMode = .center
        optionSeven.isUserInteractionEnabled = true
        optionSeven.translatesAutoresizingMaskIntoConstraints = false
        optionSeven.leadingAnchor.constraint(equalTo: b6.leadingAnchor).isActive = true
        optionSeven.topAnchor.constraint(equalTo: optionsView.topAnchor).isActive = true
        optionSeven.widthAnchor.constraint(equalToConstant: widthK).isActive = true
        optionSeven.bottomAnchor.constraint(equalTo: optionsView.bottomAnchor).isActive = true
        Paradigm.attachTapGesture(&optionSeven, target: self, action: #selector(optionSevenMethod))
        
        /// Code Ediytor
        let codeEditorView = UIVisualEffectView(effect:  UIBlurEffect(style: UIBlurEffect.Style.extraLight))
        codeEditorView.backgroundColor = UIColor.white
        contentView.addSubview(codeEditorView)
        codeEditorView.translatesAutoresizingMaskIntoConstraints=false
        codeEditorView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor).isActive = true
        codeEditorView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor).isActive=true
        codeEditorView.topAnchor.constraint(equalTo: contentView.topAnchor).isActive=true
        codeEditorHeightConstraint = codeEditorView.heightAnchor.constraint(equalToConstant: 0)
        codeEditorHeightConstraint.isActive=true
        
        
        var codeEditorCloseIcon = UIImageView(image: UIImage(named: "cancelIcon@2x.png"))
        codeEditorCloseIcon.contentMode = .center
        codeEditorView.contentView.addSubview(codeEditorCloseIcon)
        codeEditorCloseIcon.isUserInteractionEnabled = true
        codeEditorCloseIcon.translatesAutoresizingMaskIntoConstraints = false
        codeEditorCloseIcon.widthAnchor.constraint(equalToConstant: 40).isActive = true
        codeEditorCloseIcon.heightAnchor.constraint(equalToConstant: 40).isActive = true
        codeEditorCloseIcon.bottomAnchor.constraint(equalTo: codeEditorView.bottomAnchor, constant: -10).isActive = true
        codeEditorCloseIcon.centerXAnchor.constraint(equalTo: codeEditorView.centerXAnchor).isActive = true
        Paradigm.attachTapGesture(&codeEditorCloseIcon, target: self, action: #selector(closeCodeEditor))
        
        
        shaderInfoTitleLabel = Paradigm.getTextLabel(CGRect(x: 0, y: 0, width: 10, height: 10), defaultText: labelTitle, minimumScaleFactor: 10, fontSizex: 16, fontName: Paradigm.commonFontName)
        codeEditorView.contentView.addSubview(shaderInfoTitleLabel)
        shaderInfoTitleLabel.translatesAutoresizingMaskIntoConstraints=false
        shaderInfoTitleLabel.leadingAnchor.constraint(equalTo: codeEditorView.leadingAnchor, constant: 10).isActive=true
        shaderInfoTitleLabel.trailingAnchor.constraint(equalTo: codeEditorView.trailingAnchor, constant: -10).isActive=true
        shaderInfoTitleLabel.topAnchor.constraint(equalTo: codeEditorView.topAnchor, constant: 10).isActive=true
       shaderInfoTitleLabel.heightAnchor.constraint(equalToConstant: 50).isActive=true
        
        

        shaderInformationTextView.backgroundColor = UIColor.clear
        codeEditorView.contentView.addSubview(shaderInformationTextView)
        shaderInformationTextView.translatesAutoresizingMaskIntoConstraints = false
        shaderInformationTextView.topAnchor.constraint(equalTo: shaderInfoTitleLabel.bottomAnchor, constant: 2).isActive = true
        shaderInformationTextView.bottomAnchor.constraint(equalTo: codeEditorCloseIcon.topAnchor, constant: -2).isActive = true
        shaderInformationTextView.leadingAnchor.constraint(equalTo: codeEditorView.leadingAnchor, constant: 10).isActive = true
        shaderInformationTextView.trailingAnchor.constraint(equalTo: codeEditorView.trailingAnchor, constant: -10).isActive = true
        shaderInformationTextView.textAlignment = .justified
        shaderInformationTextView.textColor = UIColor.darkGray
        shaderInformationTextView.font = UIFont(name: Paradigm.commonFontName, size: 15)
        shaderInformationTextView.isEditable=false
        shaderInformationTextView.showsVerticalScrollIndicator=false
        shaderInformationTextView.text = materials[shaderIndex].note
        //shaderInformationTextView.text = "ashjgajhsdgjhagsdjhgajhsdghjagsdjhagshjdgahjgdjhagsdhjagshjd"
        
        
        /// SubOptions
        let subOptionView = UIVisualEffectView(effect:  UIBlurEffect(style: UIBlurEffect.Style.extraLight))
        contentView.addSubview(subOptionView)
        subOptionView.translatesAutoresizingMaskIntoConstraints = false
        subOptionView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: -5).isActive = true
        subOptionsViewHeightConstraint = subOptionView.heightAnchor.constraint(equalToConstant: 0)
        subOptionsViewHeightConstraint.isActive = true
        subOptionView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor).isActive = true
        subOptionView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor).isActive = true
        
        var informationCloseIcon = UIImageView(image: UIImage(named: "cancelIcon@2x.png"))
        informationCloseIcon.contentMode = .center
        subOptionView.contentView.addSubview(informationCloseIcon)
        informationCloseIcon.isUserInteractionEnabled = true
        informationCloseIcon.translatesAutoresizingMaskIntoConstraints = false
        informationCloseIcon.widthAnchor.constraint(equalToConstant: 40).isActive = true
        informationCloseIcon.heightAnchor.constraint(equalToConstant: 40).isActive = true
        informationCloseIcon.bottomAnchor.constraint(equalTo: subOptionView.bottomAnchor, constant: -10).isActive = true
        informationCloseIcon.centerXAnchor.constraint(equalTo: subOptionView.centerXAnchor).isActive = true
        Paradigm.attachTapGesture(&informationCloseIcon, target: self, action: #selector(closeSubOptions))
        
        //TableView
        subOptionsTableView = UITableView()
        subOptionsTableView.delegate = self
        subOptionsTableView.dataSource = self
        subOptionsTableView.layer.borderWidth = 2.4
        subOptionsTableView.layer.borderColor = UIColor.lightGray.withAlphaComponent(0.7).cgColor
        subOptionsTableView.layer.cornerRadius = 10
        subOptionView.contentView.addSubview(subOptionsTableView)
        subOptionsTableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        subOptionsTableView.translatesAutoresizingMaskIntoConstraints = false
        subOptionsTableView.centerXAnchor.constraint(equalTo: subOptionView.centerXAnchor).isActive = true
        subOptionsTableView.centerYAnchor.constraint(equalTo: subOptionView.centerYAnchor).isActive = true
        subOptionsTableView.widthAnchor.constraint(equalToConstant: 180).isActive = true
        subOptionsTableView.heightAnchor.constraint(equalToConstant: 220).isActive = true
        
        let arView = UIVisualEffectView(effect:  UIBlurEffect(style: UIBlurEffect.Style.extraLight))
        contentView.addSubview(arView)
        arView.translatesAutoresizingMaskIntoConstraints = false
        arView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: -5).isActive=true
        arView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor).isActive=true
        arView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor).isActive=true
        arViewHeightConstraint = arView.heightAnchor.constraint(equalToConstant: 0)
        arViewHeightConstraint.isActive=true
        
        var arCancelIcon = UIImageView(image: UIImage(named: "cancelIcon@2x.png"))
        arCancelIcon.contentMode = .center
        arView.contentView.addSubview(arCancelIcon)
        arCancelIcon.isUserInteractionEnabled = true
        arCancelIcon.translatesAutoresizingMaskIntoConstraints = false
        arCancelIcon.centerXAnchor.constraint(equalTo: arView.centerXAnchor).isActive = true
        arCancelIcon.widthAnchor.constraint(equalToConstant: 40).isActive = true
        arCancelIcon.heightAnchor.constraint(equalToConstant: 40).isActive = true
        arCancelIcon.bottomAnchor.constraint(equalTo: arView.bottomAnchor, constant: -10).isActive = true
        Paradigm.attachTapGesture(&arCancelIcon, target: self, action: #selector(cancelAREditor))
        
        if (ARConfiguration.isSupported) {
            arSceneView = ARSCNView()
            arView.contentView.addSubview(arSceneView)
            //arSceneView.layer.borderWidth=1
            arSceneView.translatesAutoresizingMaskIntoConstraints = false
            arSceneView.leadingAnchor.constraint(equalTo: arView.leadingAnchor, constant: 5).isActive=true
            arSceneView.trailingAnchor.constraint(equalTo: arView.trailingAnchor, constant: -5).isActive=true
            arSceneView.topAnchor.constraint(equalTo: arView.topAnchor, constant: 5).isActive=true
            arSceneView.bottomAnchor.constraint(equalTo: arCancelIcon.topAnchor, constant: -5).isActive=true
            // Great! let have experience of ARKIT
        } else {
            // Sorry! you don't have ARKIT support in your device
            let errorlabel = Paradigm.getTextLabel(defaultText: "This device doesnt support AR")
            arView.contentView.addSubview(errorlabel)
            errorlabel.translatesAutoresizingMaskIntoConstraints = false
            errorlabel.trailingAnchor.constraint(equalTo: arView.trailingAnchor).isActive = true
            errorlabel.leadingAnchor.constraint(equalTo: arView.leadingAnchor).isActive=true
            errorlabel.heightAnchor.constraint(equalToConstant: 60).isActive = true
            errorlabel.centerXAnchor.constraint(equalTo: arView.centerXAnchor).isActive=true
            errorlabel.centerYAnchor.constraint(equalTo: arView.centerYAnchor).isActive=true
        }
    
    }
    
    //MARK: - AUTOLAYOUT ANIMATIONS
    /*! It was really really redundant to call the animation block again and again.
     - In the closure, you can set the constraints properties
     - Animation block will take care of layoutIfNeeded
     - There is a default animation duration also*/
    func constraintsAnimations(_ duration: Double = 0.5, code: () -> ()) {
        code()
        UIView.animate(withDuration: duration) {
            self.view.layoutIfNeeded()
        }
        
    }
    
    //MARK: - SELECT OBJECTS
    /*! ---------- PREVIOUS SCENE OPTION ----------*/
    @objc func optionOneMethod() {
        currentOption = 0
        shaderIndex-=1
        if(shaderIndex < 0) { shaderIndex = 0 }
        sceneView.scene = self.setupScene(shader: materials[shaderIndex], color: currentColor, shape: currentShape, nodeAnimating: currentAnimationStatus)
        label.text = materials[shaderIndex].name
        shaderInfoTitleLabel.text = materials[shaderIndex].name
        shaderInformationTextView.text = materials[shaderIndex].note
    }
    
    /*! ---------- SELECT OBJECTS OPTION ----------*/
    @objc func optionTwoMethod() {
        currentOption = 1
        currentTableOptions = objects
        self.subOptionsTableView.reloadData()
        self.constraintsAnimations {
            subOptionsViewHeightConstraint.constant = contentViewHeightConstraint.constant
        }
    }
    
    /*! ---------- SELECT COLOR OPTION ----------*/
    @objc func optionThreeMethod() {
        currentOption = 2
        currentTableOptions = colors
        self.subOptionsTableView.reloadData()
        self.constraintsAnimations {
            subOptionsViewHeightConstraint.constant = contentViewHeightConstraint.constant
        }
    }
    
    /*! ---------- SELECT INFORMATION OPTION ----------*/
    @objc func optionFourMethod() {
        currentOption = 3
        self.constraintsAnimations {
            codeEditorHeightConstraint.constant = contentViewHeightConstraint.constant
        }
    }
    
    /*! ---------- ANIMATION TOGGLE OPTION ----------*/
    @objc func optionFiveMethod() {
        currentOption = 4
        if(currentAnimationStatus == true) {
            currentAnimationStatus = false
            optionFive.image = UIImage(named: "stopAnimateIcon@2x.png")
        }else {
            currentAnimationStatus = true
            optionFive.image = UIImage(named: "animateIcon@2x.png")
        }
        sceneView.scene = self.setupScene(shader: materials[shaderIndex], color: currentColor, shape: currentShape, nodeAnimating: currentAnimationStatus)
    }
    
    /*! ---------- PLAY IN AR OPTION ----------*/
    @objc func optionSixMethod() {
        currentOption = 5
        self.constraintsAnimations {
            arViewHeightConstraint.constant = contentViewHeightConstraint.constant
        }
        //Check for AR support
        if (ARConfiguration.isSupported) {
            self.setupARObject(shader: materials[shaderIndex], color: currentColor, shape: currentShape, nodeAnimating: currentAnimationStatus)
            arSceneView.session.run(arConfiguration)
        }
    }
    
    /*! ---------- SELECT NEXT OPTION ----------*/
    @objc func optionSevenMethod() {
        currentOption = 6
        shaderIndex+=1
        if(shaderIndex > materials.count-1) {
            shaderIndex = materials.count-1
        }
        sceneView.scene = self.setupScene(shader: materials[shaderIndex], color: currentColor, shape: currentShape, nodeAnimating: currentAnimationStatus)
        label.text = materials[shaderIndex].name
        shaderInfoTitleLabel.text = materials[shaderIndex].name
        shaderInformationTextView.text = materials[shaderIndex].note
    }
    
    //MARK: - SUBOPTIONS METHODS
    /*! ---------- CANCEL AR MODE OPTION ----------*/
    @objc func cancelAREditor() {
        self.constraintsAnimations {
            arViewHeightConstraint.constant = 0
        }
        if (ARConfiguration.isSupported) {
            arSceneView.session.pause()
        }
    }
    
     /*! ---------- CLOSE OPTIONS OPTION ----------*/
    @objc func closeSubOptions() {
        self.constraintsAnimations {
             subOptionsViewHeightConstraint.constant = 0
        }
    }
    
     /*! ---------- CLOSE EDITOR OPTION ----------*/
    @objc func closeCodeEditor() {
        self.constraintsAnimations {
            codeEditorHeightConstraint.constant = 0
        }
    }
    
     /*! ---------- S ----------*/
    @objc func selectCodeEditor() {
        self.subOptionsTableView.reloadData()
        self.constraintsAnimations {
            subOptionsViewHeightConstraint.constant = contentViewHeightConstraint.constant
        }
    }
    
    
    
    
    //MARK: - TABLEVIEW DELEGATE METHODS
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return currentTableOptions.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "Cell")!
        cell.textLabel?.font = UIFont(name: Paradigm.commonFontName, size: 12)
        cell.textLabel?.textAlignment = .center
        cell.textLabel?.text = currentTableOptions[indexPath.row]
        return cell
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if(currentOption == 1) {
            currentShape = currentTableOptions[indexPath.row]
            print("Selected Shape: \(currentShape) - Count: \(currentShape.count)")
            sceneView.scene = self.setupScene(shader: materials[shaderIndex], color: currentColor, shape: currentShape, nodeAnimating: currentAnimationStatus)
            self.closeSubOptions()
        }else {
            currentColor = currentTableOptions[indexPath.row]
            sceneView.scene = self.setupScene(shader: materials[shaderIndex], color: currentColor, shape: currentShape, nodeAnimating: currentAnimationStatus)
            self.closeSubOptions()
        }
    }
    
}
