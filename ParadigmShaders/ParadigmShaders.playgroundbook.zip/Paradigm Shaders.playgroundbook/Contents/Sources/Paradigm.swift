import Foundation
import PlaygroundSupport
import UIKit
import SpriteKit
import CoreFoundation

/*
 -  This class is used to access basic functions that will be used in almost all the classes.
 -  It is like a neutral class
 -  A lot of functions will be static
 -  It is kind of like a helper class and heart of
 */



public class Paradigm {
    
    /// Common Font Name
    public static let commonFontName = "AvenirNext-Regular"
    
    ///Some Constants
    public static let introductionBackgroundColor = UIColor.white
    
    ///Signature Font
    public static var signatureFontName = "Signerica Medium"
    
    //MARK: - Helper Methods
    /*This function will assign a view to the Playground live view*/
    public static func makeViewLive<T>(_ view: inout T) where T: UIView {
        PlaygroundPage.current.liveView = view
    }
    
    
    //MARK: - Bundle Methods
    /*!This function is used to fetch shaders from Bundle and that will be used to assign it to all geometries*/
    public static func getShader(from filename: String, extension_x: String) -> String {
        do {
            if let directory = Bundle.main.url(forResource: filename, withExtension: extension_x) {
                return try String(contentsOf: directory, encoding: .utf8)
            }
        } catch {
            print(error)
        }
        return ""
    }
    
    //MARK: - Gradient Methods
    /*!Add a gradient layer to a view*/
    public static func attachGradient<T>(_ view: inout T, start: UIColor, end: UIColor) where T:UIView {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
        gradientLayer.colors = [start.cgColor, end.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 0, y: 1)
        gradientLayer.locations = [0.5,1.0]
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    /*! Make a view circle.
     1. It check for the height and width and they need to be the same
     */
    public static func makeViewCircle<T>(_ view: T) where T:UIView {
        //Check oif views have valid values
        guard view.frame.width == view.frame.height else { return }
        view.layer.cornerRadius = view.frame.width/2
    }
    
    /*! Create a text label.
     */
    public static func getTextLabel(_ frame: CGRect  = CGRect(x: 0, y: 0, width: 100, height: 20), defaultText: String, minimumScaleFactor: CGFloat = 10, fontSizex: CGFloat = 18, fontName:String = "AvenirNext-Regular") -> UILabel{
        
        loadCustomFonts("SignericaMedium", type: "ttf")
        let label = UILabel(frame: frame)
        label.textAlignment = .center
        label.text = defaultText
        label.numberOfLines = 1
        label.minimumScaleFactor = minimumScaleFactor
        label.adjustsFontSizeToFitWidth = true
        label.font = UIFont(name: fontName, size: fontSizex)
        //label.font = UIFont(name: signatureFontName, size: fontSize)
        return label
    }
    
    
    

    /*  This is required to get custom fonts*/
    public static func loadCustomFonts(_ name:String, type:String) {
        let cfURL = Bundle.main.url(forResource: name, withExtension: type) as! CFURL
        CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil) 
    }
    
    public static func setShadow<T>(_view: inout T, _shadowColor: UIColor = UIColor.darkGray, _opacity: Float = 0.3, _cornerRadius: CGFloat = 0) where T: UIView {
        //check for the object type. It has to be a subclass of UIView
        if(_view.isKind(of: UIView.self)) {
            _view.layer.cornerRadius = 3
            _view.layer.shadowColor = _shadowColor.cgColor
            _view.layer.shadowOffset = CGSize(width: 0, height: 1)
            _view.layer.shadowOpacity = _opacity
            _view.layer.shadowRadius = 5
        }
    }
    
    
    
}


//MARK: - GESTURES
/*! This extension holds user interactionc methods*/
extension Paradigm {
    
    //MARK: - Tap Gesture
    public static func attachTapGesture<T>(_ view: inout T, target: Any?, action: Selector?) where T: UIView{
        let tap = UITapGestureRecognizer(target: target, action: action)
        tap.numberOfTapsRequired = 1
        tap.numberOfTouchesRequired = 1
        view.addGestureRecognizer(tap)
    }
    
    //MARK: - Swipe Gesture
    public func attachSwipeGesture<T>(_ sceneView: inout T, direction: UISwipeGestureRecognizer.Direction, target: Any?, action: Selector?) where T: UIView {
        let swipe = UISwipeGestureRecognizer(target: target, action: action)
        swipe.direction = direction
        sceneView.addGestureRecognizer(swipe)
    }
    
}





