import Foundation
import SceneKit
import MetalPerformanceShaders
import MetalKit
import Metal
import UIKit


public class Scene3D {
    
    //MARK: - PROPERTIES
    /// This is the sceneView
    var sceneView: SCNView? = nil
    
    /// Add a camera
    var cameraNode:SCNNode!
    
    /// Light Node
    var lightNode:SCNNode!
    
    /// scene object will take care of the current scene.
    var scene:SCNScene?
    
    /// Metal device is needed for Metal Libraries that will be used for shaders
    lazy var device = MTLCreateSystemDefaultDevice()
    
    ///LookAt constraints
    var lookAtConstraints:SCNLookAtConstraint?
    
    //MARK: - BASIC METHODS
    /// Init function
    public init() {
        
    }
    
    /*public init(_ frame_x: CGRect) {
        
    }*/
    
    
    //MARK: - CONSTRAINTS
    /*! This function returns a LookCOnstraints
     1. target - SCNNode that will be looked at
     2. gimbalLock - SE*/
    public func getLookConstraint(_ target: SCNNode, gimbalLock: Bool = true) -> SCNLookAtConstraint{
        let constraints = SCNLookAtConstraint(target: target)
        constraints.isGimbalLockEnabled = gimbalLock
        return constraints
    }
    
    /*! This function attaches constraints to a node
     1. node - SE
     2. gimbalLock - SE*/
    public func attachLookConstraint(_ node: inout SCNNode, constraints: SCNConstraint?) {
        guard constraints != nil else { return }
        node.constraints = [constraints!]
    }

}

/*
    - This class is used to attach shaders
    - This includes SCNTechnique and Metal Shaders
    - It also declares metal elements*/
extension Scene3D {
    
    //MARK: - METAL
    /*  This will create a library that will be used to run shaders
     1. device - Metal device that will do the job
     2. name - File name of the shader
     3. type - shader as a default type*/
    public func createLibraryForShaders(_ device: MTLDevice ,name: String, type: String = "metal") {
        
    
        if let path = Bundle.main.path(forResource: name, ofType: type) {
            do {
                let contents = try String(contentsOf: URL(fileURLWithPath: path))
                _ = try device.makeLibrary(source: contents, options: nil)
            } catch { //error
                //print(error)
            }
        }
    }
    
    //MARK: - SCNTECHNIQUE
    /*! Attach SCNTechnique to a scene
     1. sceneView - It is an iout variable that will be assigned a technique
     2. technique - It is an optional value that will be attached */
    public func attachTechniqueToScene(_ sceneView: inout SCNView, technique: SCNTechnique?) {
        guard technique != nil else { return }
        sceneView.technique = technique
    }
    
    /*!  Get technique data from the plist and that will be used for assigning to a sceneview
     1. technique - String will be used for making
     2. type - By default it is plist*/
    public func getTechniqueData(_ name: String, type: String = "plist") -> [String : AnyObject]?{
        var plistDictionary:[String : AnyObject]?
        if let path = Bundle.main.path(forResource: name, ofType: type) {
            if let plistDict = NSDictionary(contentsOfFile: path)  {
                plistDictionary = plistDict as? [String : AnyObject]
            }
        }
        return plistDictionary
    }
    
    /*! It create a technique
     1. name - Technique name
     2. type - plist is the default value*/
    public func getTechnique(_ name: String, type: String = "plist") -> SCNTechnique?{
        guard let data = self.getTechniqueData(name, type: type) else { return nil }
        return SCNTechnique(dictionary: data)
    }
    
}

/*! This extension is used for making all 3D Camera*/
extension Scene3D {
    
    //MARK: - CAMERA
    /*! This function returns a camera with basic properties defined.
     ! It does not return it with a node
     1. threshold - default is 0.8
     2. intensity
     */
    public func attachBloomProperties(_ camera: inout SCNCamera, threshold: CGFloat = 0.8, intensity: CGFloat = 2, blurRadius: CGFloat = 16, exposureAdaption: Bool = false, hdr: Bool = true) {
        camera.wantsHDR = hdr
        camera.bloomThreshold = threshold
        camera.bloomIntensity = intensity
        camera.bloomBlurRadius = blurRadius
        camera.wantsExposureAdaptation = exposureAdaption
    }
    
    /*! This function returns a camera.
     ! You dont always need a not node.
     1. bloomproperties - It is a bool and by default it is false*/
    public func getCamera(_ bloomproperties: Bool = false) -> SCNCamera {
        var camera = SCNCamera()
        if(bloomproperties){
            self.attachBloomProperties(&camera)
        }
        return camera
    }
    
    /*! This function returns camera node.
     1. position - It is the camera position and default is 0,0,2*/
    public func getCameraWithNode(_ camera: SCNCamera? ,position: SCNVector3 = SCNVector3(0,0,2)) -> SCNNode{
        
        let cameraNode = SCNNode()
        var camerax = self.getCamera()
        if(camera != nil) {
            camerax = camera!
        }
        cameraNode.camera = camerax
        cameraNode.position = position
        return cameraNode
    }
}

/*  This class is for camera functionalities*/
extension Scene3D {
    
    /*---------- GEOMETRIES ----------*/
    
    //MARK:- GENERAL
    /*! It returns SCNNode.
        Dont have to rewrite node for geometries
     1. geometry - SE
     2. position - SE
     */
    public func getGeometryNode(_ geometry: SCNGeometry, position: SCNVector3 = SCNVector3(0,0,0)) -> SCNNode {
        let node = SCNNode(geometry: geometry)
        node.position = position
        return node
    }
    
    /*! This function attaches material to a geometry.Sometimes it happens that you may need it during initialization
     1. material - It is optional
     2. geometry - SE*/
    public func attachMaterialToGeometry<T>(_ geometry: inout T, materials: SCNMaterial?) where T:SCNGeometry  {
        guard materials != nil else { return }
         geometry.materials = [materials!]
        if(materials != nil) {
            geometry.materials = [materials!]
        }
    }
    
    //MARK: - SCNBOX
    /*! This function works on a box and return it placed in a node.
     1. It takes basic properties as arguments
     2. It also takes position and default is 0,0,0
     3. You can also attach a material to it. It is an optional value.
     */
    public func getBoxWithNode(_ width: CGFloat = 1, height: CGFloat = 1, length: CGFloat = 1, cornerRadius: CGFloat = 0, position: SCNVector3 = SCNVector3(0,0,0), materials: SCNMaterial?) -> SCNNode{
        
        var box = SCNBox(width: width, height: height, length: length, chamferRadius: cornerRadius)
        self.attachMaterialToGeometry(&box, materials: materials)
        return getGeometryNode(box, position: position)
    }
    
    
    //MARK: - SPHERE
    /*! This function works on a sphere and returns a node of that sphere.
     1. It takes basic properties as arguments
     2. It also takes position and default is 0,0,0
     3. You can also attach a material to it. It is an optional value.
     */
    public func getSphereWithNode(_ radius: CGFloat = 1, position: SCNVector3 = SCNVector3(0,0,0), materials: SCNMaterial?) -> SCNNode{
        
        var sphere = SCNSphere(radius: radius)
        self.attachMaterialToGeometry(&sphere, materials: materials)
        return getGeometryNode(sphere, position: position)
    }
    
    //MARK: - Cylinder
    //Cylinder
    public func getCylinderNode(_ radius:CGFloat = 1, height: CGFloat = 2, position: SCNVector3 = SCNVector3(0,0,0), materials: SCNMaterial?) -> SCNNode{
        
        var cylinderGeomerty = SCNCylinder(radius: radius, height: height)
        let cylinderNode = SCNNode(geometry: cylinderGeomerty)
        self.attachMaterialToGeometry(&cylinderGeomerty, materials: materials)
        cylinderNode.position = position
        return cylinderNode
    }
    
    //MARK: - Capsule
    //Capsule
    public func getCapsuleNode(_ radius:CGFloat = 0.5, height:CGFloat=1, position: SCNVector3 = SCNVector3(0,0,0), material:SCNMaterial?) -> SCNNode{
        var capsule = SCNCapsule(capRadius: radius, height: height)
        let capsuleNode = SCNNode(geometry: capsule)
        self.attachMaterialToGeometry(&capsule, materials: material)
        capsuleNode.position = position
        return capsuleNode
        
    }
    
    //MARK: - Torus
    public func getTorusNode(_ ringRadius: CGFloat = 1, pipeRadius: CGFloat = 1, position: SCNVector3 = SCNVector3(0,0,0), materials: SCNMaterial?) -> SCNNode {
        var torus = SCNTorus(ringRadius: ringRadius, pipeRadius: pipeRadius)
        let torusNode = SCNNode(geometry: torus)
        self.attachMaterialToGeometry(&torus, materials: materials)
        torusNode.position = position
        return torusNode
    }
    
    //MARK: - Pyramid
    public func getPyramidNode(_ width:CGFloat = 1, height: CGFloat = 1, length: CGFloat = 1,position: SCNVector3 = SCNVector3(0,0,0), materials: SCNMaterial?) -> SCNNode {
        var pyramid = SCNPyramid(width: width, height: height, length: length)
        let pyramidNode = SCNNode(geometry: pyramid)
        self.attachMaterialToGeometry(&pyramid, materials: materials)
        pyramidNode.position = position
        return pyramidNode
    }
    
    //MARK: - Plane Geometry
    public func getPlane(_ width:CGFloat = 3, height: CGFloat = 3, eulerAngles: SCNVector3, position: SCNVector3 = SCNVector3(0,0,0), materials: SCNMaterial?) -> SCNNode{
        var planeGeometry = SCNPlane(width: width, height: height)
        let planeNode = SCNNode(geometry: planeGeometry)
        planeNode.eulerAngles = eulerAngles //SCNVector3(x: GLKMathDegreesToRadians(0), y: GLKMathDegreesToRadians(-90), z: 0)
        self.attachMaterialToGeometry(&planeGeometry, materials: materials)
        planeNode.position = position
        return planeNode
    }
    
    /*! Get objects with strings*/
    public func getNodeFromString(_ name:String,position:SCNVector3 = SCNVector3(0,0,0), materials:SCNMaterial?) -> SCNNode{
        
        var node = self.getBoxWithNode(1, height: 1, length: 1, cornerRadius: 0, position: position, materials: materials)
        switch name {
        case "Sphere":
            node = self.getSphereWithNode(0.5, position: position, materials: materials)
        case "Cylinder":
            node = self.getCylinderNode(1, height: 1, position: position, materials: materials)
        case "Torus":
            node = self.getTorusNode(1, pipeRadius: 1, position: position, materials: materials)
        case "Pyramid":
            node = self.getPyramidNode(1, height: 1, length: 1, position: position, materials: materials)
        default:
            print("default")
        }
        return node
    }
    
    /*! This method is used to get Material just from the string. It is basically a hard coded function.*/
    func getMaterialFromColorString(_ color: String, shaders:NSMutableDictionary?) -> SCNMaterial? {
        var currentColor = UIColor.red
        switch color {
        case "Blue":
            currentColor = UIColor.blue
        case "Black":
            currentColor = UIColor.black
        case "Green":
            currentColor = UIColor.green
        case "Yellow":
            currentColor = UIColor.yellow
        default:
            print("Default")
        }
        let material = self.getMaterial(currentColor, shaders: nil, fresnelEffect: false)
        return material
    }
    
    /*! This method is used to get color just from the string. It is basically a hard coded function.*/
    public func getColorFromColorString(_ color: String) -> UIColor {
        var currentColor = UIColor.red
        switch color {
        case "Blue":
            currentColor = UIColor.blue
        case "Black":
            currentColor = UIColor.black
        case "Green":
            currentColor = UIColor.green
        case "Yellow":
            currentColor = UIColor.yellow
        default:
            print("Default")
        }
        return currentColor
    }
    
    
    //MARK: - MATERIAL NEEDS SOME WORK
    /*!
     This is a method that will make attach a properties to a material that will be attached to a SCNNode.
     Properties can be shaders and a lot of different things. By default the material will have a red colour.
     1. diffuse_color - This will be a diffuse color and the default value is red
     2. shaders - This will be a dictionary that will be a optional value because it can or it cannot have a string in it*/
    public func getMaterial(_ diffuse_color: UIColor = .red, shaders: NSMutableDictionary?, fresnelEffect: Bool = true) -> SCNMaterial {
        
        var material = SCNMaterial()
        material.diffuse.contents = diffuse_color
        if(fresnelEffect){
            material = self.addFresnelEffect(material)
        }
        if let shaders_x = shaders {
             material.shaderModifiers = (shaders_x as! [SCNShaderModifierEntryPoint : String])
        }
        return material
    }
    
    /*!
     1. This method will be used to add Fresnel effect to a material.
     2. material - material that needs to be added fresnel
     3. reflectiveColor - Default is UIColor(red: 0, green: 0.764, blue: 1, alpha: 1)
     4. transparentColor - Default is UIColor.black.withAlphaComponent(0.3)
     5. intensity - Default is 3
     It is not going to cover all the properties. Will that in future if required.
     
     */
    
    public func addFresnelEffect(_ material: SCNMaterial, reflectiveColor: UIColor = UIColor(red: 0, green: 0.764, blue: 1, alpha: 1), transparentColor: UIColor = UIColor.black.withAlphaComponent(0.3), intensity: CGFloat = 4) -> SCNMaterial {
        let material = material
        material.reflective.contents = reflectiveColor
        material.reflective.intensity = intensity
        material.transparent.contents = transparentColor
        material.transparencyMode = .default
        material.fresnelExponent = 4
        return material
    }
    
    //MARK: - SHADERS
    
    /*! This function is used to append shader modifiers
     1. dictionary - it is an inout variable
     2. others - SE*/
    public func attachEntryPointFromFile(_ dictionary: inout NSMutableDictionary, entrypoint: SCNShaderModifierEntryPoint, name: String, type: String) {
        dictionary[entrypoint] = Paradigm.getShader(from: name, extension_x: type)
    }
    
    public func attachEntryPointFromString(_ dictionary: inout NSMutableDictionary, entrypoint: SCNShaderModifierEntryPoint, code: String) {
        dictionary[entrypoint] = code
    }
    
    /*!
     This is a method that will make attach a properties to a material that will be attached to a SCNNode.
     Properties can be shaders and a lot of different things. By default the material will have a red colour.
     1. diffuse_color - This will be a diffuse color and the default value is red
     2. shaders - This will be a dictionary that will be a optional value because it can or it cannot have a string in it
     */
    public func attachShaderModifier(_ material: inout SCNMaterial, shaders: NSMutableDictionary) {
        material.shaderModifiers = (shaders as! [SCNShaderModifierEntryPoint : String])
    }
    
    /*!
     This method is used to attach SCNProgram. There will be two parameters
     1. fragment_function - It will be the name of fargment function
     2. vertexFunction - Ir will be the name of vertex function
     */
    
    public func attachShaderPrograms(_ material: inout SCNMaterial?, fragment_function: String, vertex_function: String, file: String) {
        
        guard material != nil else { return }
        //Create a library
        //self.createLibraryForShaders(device!, name:file)
        //Get the program
        let program = SCNProgram()
        program.fragmentFunctionName = fragment_function
        program.vertexFunctionName = vertex_function
        material!.program = program
        
    }
    
    /*! It set images to materials.
      ! These images are used by metal shaders
     1. material - This is optional and it is an inout variable
     2. imageName- Image name
     3. key - for the property and it has to be the same as defined in metal shaders else it wont work*/
    public func attachTextureToMaterial(_ material: inout SCNMaterial?, imageName: String, key: String?) {
        
        guard material != nil, key != nil  else { return }
        let image = UIImage(named: imageName)
        let imageProperty = SCNMaterialProperty(contents: image!)
        material!.setValue(imageProperty, forKey: key!)
        
    }
    
    /*! It set images to materials.
     ! These images are used by metal shaders
     1. material - This is optional and it is an inout variable
     2. image- Image
     3. key - for the property and it has to be the same as defined in metal shaders else it wont work*/
    public func attachImageToMaterial(_ material: SCNMaterial? ,image: UIImage?, key: String?) {
        
        guard material != nil, image != nil, key != nil else { return }
        let imageProperty = SCNMaterialProperty(contents: image!)
        material!.setValue(imageProperty, forKey: key!)
        
    }
    
    
    //MARK: - SCENE METHODS
    /*! This method returns a scene
     1. name - name of a scene.*/
    public func getScene(_ name: String?) -> SCNScene{
        guard name != nil else { return SCNScene() }
        return SCNScene(named: name!)!
    }
    
    /*! This method returns a sceneview
     1. allowsCameraControl - Default control that makes the scene interactable.
     This option is just for testing and by default it is false
     2. showStatistics - This option makes me shows rendering info and it is only there for testing and by default it is false
     3. playing - It is used to when it uses delegate methods
     4. delegate - It is optional */
    public func getSceneView(_ frame: CGRect, allowsCameraControl: Bool = false, showStatistics: Bool = false, playing: Bool = false, scene: SCNScene?, delegate: SCNSceneRendererDelegate?) -> SCNView{
        
        let sceneView = SCNView(frame: frame)
        sceneView.allowsCameraControl = allowsCameraControl
        sceneView.showsStatistics = showStatistics
        sceneView.isPlaying = playing
        if(delegate != nil) {
            sceneView.delegate = delegate
        }
        if(scene != nil) {
            sceneView.scene = scene
        }
        return sceneView
    }
    
    //MARK: - LIGHT
    /*! This function returns a lightNode
     1. type - It takes in a light type and returns light function
     */
    public func getLight(_ type: SCNLight.LightType = .ambient) -> SCNLight{
        let light = SCNLight()
        light.type = type
        return light
    }
    
    /*! This function returns a light that will return a node.
     1. light - Optional and it checks if there is a light source else it create a light object
     2. position - Light position
     */
    public func getLightNode(_ light: SCNLight? ,position: SCNVector3 = SCNVector3(0,0,0)) -> SCNNode{
        
        let lightNode = SCNNode()
        var lightx = self.getLight()
        if(light != nil) {
            lightx = light!
        }
        lightNode.light = lightx
        lightNode.position = position
        return lightNode
    }

}
