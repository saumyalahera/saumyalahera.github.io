/*:
 # Game PEMDAS
 
 Enough of serious stuff! The PEMDAS Rule is a set of rules that prioritize the order of calculations, that is, which operation to perform first. Otherwise, it is possible to get multiple or different answers. We don’t want that to happen.
 
 
 
 ## PEMDAS ORDER
 - P - Parentheses first
 - E - Exponents (ie Powers and Square Roots, etc.)
 - MD - Multiplication and Division (left-to-right)
 - AS - Addition and Subtraction (left-to-right)
 
 
 This page is a game where you will have to play with PEMDAS Rules.
 - You will have a question on top and options at the bottom.
 - Question is such that you will have to count shapes or colours and place the count the question and get the result
 - It is not that complicated
 - Also, it uses a lot of shaders to confuse you.
 
 
 
 ## Why shaders in this game?
 
 To show you how shaders can give different effects during real time rendering. Shaders in games are used to simulate a lot of things. Animations are used to give you hints.
 
 
 
 ## Example
 
 Let me assume that there are 3 cubes and 3 geometries of red color.
 Now, the question may be like this "Cubes + Red". So the equation is 3 + 3, and the answer is 6
 
 - Red + Cube * Red (3 + 3 * 3) = 12
 
 Let me assume that there are 4 cubes and 3 geometries of red color and 5 geometries of blue color.
 
 - Blue + Cubes + Red (5 + 4 + 3) = 12
 
 - Important: The results are in Int values. so be careful about that. So, if the result is 7.5(Float), the answer in Int will be 7.
 
 
 
 ## Distractions
 
 This games uses a lot of shaders and they are used to trick you.
 
 - Lights are used to trick you with colours.
 - I am using directional lights. So, you may get confused with the black shadow. It is a shadow and not the color.
 - Enjoy!
 */
